import discord
from discord.ext import commands
import json
from pathlib import Path

def get_color(guild_id: int):
    # Caminho até a raiz do projeto
    base_path = Path(__file__).resolve().parent.parent
    file_path = base_path / "aparencia.json"

    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    guild_data = data.get(str(guild_id))
    if not guild_data:
        raise KeyError(f"Nenhuma configuração encontrada para o servidor {guild_id}")

    cor = guild_data["cor"]
    return int(cor.replace("#", ""), 16)

class Clear(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(aliases=["limpar"])
    @commands.has_permissions(manage_messages=True)
    async def clear(self, ctx, quantidade: int):
        if quantidade <= 0:
            embed = discord.Embed(
                description="Digite um valor **maior que 0** para excluir mensagens.",
                color=get_color(ctx.guild.id)
            )
            await ctx.send(embed=embed, delete_after=5)
            return

        # Apaga a quantidade + 1 (para remover também o comando do usuário)
        await ctx.channel.purge(limit=quantidade + 1)

        embed = discord.Embed(
            description=f"``{quantidade}`` mensagens foram limpas por → ``{ctx.author}``",
            color=get_color(ctx.guild.id)
        )
        embed.set_footer(text=f"Executado por {ctx.author}", icon_url=ctx.author.display_avatar.url)

        msg = await ctx.send(embed=embed)
        await msg.delete(delay=5)

    @clear.error
    async def clear_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            embed = discord.Embed(
                description="Você precisa da permissão `Gerenciar mensagens` para usar este comando.",
                color=get_color(ctx.guild.id)
            )
            await ctx.send(embed=embed, delete_after=5)
        else:
            embed = discord.Embed(
                description=f"Erro ao executar clear: `{error}`",
                color=get_color(ctx.guild.id)
            )
            await ctx.send(embed=embed, delete_after=5)

async def setup(bot):
    await bot.add_cog(Clear(bot))
