import discord
from discord.ext import commands
import json
import os

# -----------------------------
# Arquivos
# -----------------------------
BLACKLIST_FILE = "blacklist.json"
APARENCIA_FILE = "aparencia.json"


# -----------------------------
# Funções utilitárias
# -----------------------------
def load_blacklist():
    if not os.path.exists(BLACKLIST_FILE):
        return {}
    with open(BLACKLIST_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_blacklist(data):
    with open(BLACKLIST_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def load_aparencia():
    if not os.path.exists(APARENCIA_FILE):
        return {}
    with open(APARENCIA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def create_base_embed(usuario, titulo, descricao, guild_id=None):
    data = load_aparencia()
    cor_hex = "#2f3136"
    if guild_id and str(guild_id) in data:
        cor_hex = data[str(guild_id)].get("cor", cor_hex)

    embed = discord.Embed(
        title=titulo,
        description=descricao,
        color=int(cor_hex.replace("#", ""), 16)
    )
    embed.set_footer(text=f"Solicitado por {usuario.name}")
    return embed


# -----------------------------
# Views de configuração
# -----------------------------
class BlacklistConfigView(discord.ui.View):
    def __init__(self, bot, autor):
        super().__init__(timeout=None)
        self.bot = bot
        self.autor = autor

    @discord.ui.button(label="Definir limite", style=discord.ButtonStyle.gray)
    async def definir_limite(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.autor:
            return await interaction.response.send_message("Você não pode usar este menu.", ephemeral=True)

        await interaction.response.send_message(
            "Envie o ID do usuário e o limite, separados por espaço.\nExemplo: `123456789012345678 5`",
            ephemeral=True
        )

        def check(m):
            return m.author == self.autor and m.channel == interaction.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=30)
            parts = msg.content.strip().split()
            if len(parts) != 2:
                return await interaction.followup.send("Formato inválido! Use: `<id_usuario> <limite>`", ephemeral=True)

            user_id, limite = parts
            user_id = str(int(user_id))
            limite = int(limite)

        except ValueError:
            return await interaction.followup.send("Erro: forneça apenas números válidos.", ephemeral=True)
        except Exception:
            return await interaction.followup.send("Tempo esgotado para definir limite.", ephemeral=True)

        data = load_blacklist()
        guild_data = data.get(str(interaction.guild.id), {"ids": {}, "limites": {}})
        guild_data["limites"][user_id] = limite
        data[str(interaction.guild.id)] = guild_data
        save_blacklist(data)

        await interaction.followup.send(
            f"Limite de `{limite}` IDs definido para o usuário <@{user_id}>.", ephemeral=True
        )


# -----------------------------
# Views de gerenciamento
# -----------------------------
class BlacklistGerenciamentoView(discord.ui.View):
    def __init__(self, bot, autor):
        super().__init__(timeout=None)
        self.bot = bot
        self.autor = autor

    @discord.ui.button(label="Adicionar ID", style=discord.ButtonStyle.primary)
    async def adicionar_id(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.autor:
            return await interaction.response.send_message("Você não pode usar este menu.", ephemeral=True)

        await interaction.response.send_message("Digite o ID que deseja adicionar:", ephemeral=True)

        def check(m):
            return m.author == self.autor and m.channel == interaction.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=30)
            user_id = msg.content.strip()
            int(user_id)  # valida se é número
        except ValueError:
            return await interaction.followup.send("Erro: forneça apenas um número válido.", ephemeral=True)
        except Exception:
            return await interaction.followup.send("Tempo esgotado para digitar o ID.", ephemeral=True)

        data = load_blacklist()
        guild_data = data.get(str(interaction.guild.id), {"ids": {}, "limites": {}})
        if "limites" not in guild_data:
            guild_data["limites"] = {}

        limite = guild_data["limites"].get(str(self.autor.id))
        meus_ids = [uid for uid, autor in guild_data["ids"].items() if autor == str(self.autor.id)]

        if limite and len(meus_ids) >= limite:
            return await interaction.followup.send("Você atingiu o seu limite de IDs na blacklist.", ephemeral=True)

        guild_data["ids"][str(user_id)] = str(self.autor.id)
        data[str(interaction.guild.id)] = guild_data
        save_blacklist(data)

        await interaction.followup.send(f"ID `{user_id}` adicionado à blacklist.", ephemeral=True)

        # Ban mesmo que não esteja no servidor
        try:
            await interaction.guild.ban(discord.Object(id=int(user_id)), reason="Blacklist aplicada.")
        except discord.Forbidden:
            await interaction.followup.send("Não tenho permissão para banir este usuário.", ephemeral=True)
        except discord.NotFound:
            await interaction.followup.send("Não foi possível encontrar este usuário no Discord.", ephemeral=True)

    @discord.ui.button(label="Remover ID", style=discord.ButtonStyle.danger)
    async def remover_id(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.autor:
            return await interaction.response.send_message("Você não pode usar este menu.", ephemeral=True)

        await interaction.response.send_message("Digite o ID que deseja remover:", ephemeral=True)

        def check(m):
            return m.author == self.autor and m.channel == interaction.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=30)
            user_id = msg.content.strip()
            int(user_id)  # valida se é número
        except ValueError:
            return await interaction.followup.send("Erro: forneça apenas um número válido.", ephemeral=True)
        except Exception:
            return await interaction.followup.send("Tempo esgotado.", ephemeral=True)

        data = load_blacklist()
        guild_data = data.get(str(interaction.guild.id), {"ids": {}, "limites": {}})

        if user_id not in guild_data["ids"]:
            return await interaction.followup.send("Este ID não está na blacklist.", ephemeral=True)

        del guild_data["ids"][user_id]
        data[str(interaction.guild.id)] = guild_data
        save_blacklist(data)

        await interaction.followup.send(f"ID `{user_id}` removido da blacklist.", ephemeral=True)

    @discord.ui.button(label="Listar IDs", style=discord.ButtonStyle.secondary)
    async def listar_ids(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.autor:
            return await interaction.response.send_message("Você não pode usar este menu.", ephemeral=True)

        data = load_blacklist()
        guild_data = data.get(str(interaction.guild.id), {"ids": {}, "limites": {}})

        ids_usuario = [uid for uid, autor in guild_data["ids"].items() if autor == str(self.autor.id)]

        if not ids_usuario:
            return await interaction.response.send_message("Você não aplicou nenhum ID na blacklist.", ephemeral=True)

        lista = "\n".join(f"- `{uid}`" for uid in ids_usuario)
        await interaction.response.send_message(f"Seus IDs aplicados:\n{lista}", ephemeral=True)


# -----------------------------
# Embeds (ctx ou interaction)
# -----------------------------
async def exibir_embed_blacklist_config(ctx, bot):
    usuario = ctx.author if hasattr(ctx, "author") else ctx.user
    data = load_blacklist()
    guild_data = data.get(str(ctx.guild.id), {"ids": {}, "limites": {}})
    limite = guild_data.get("limites", {}).get(str(usuario.id), "Não definido")

    descricao = (
        "Aqui você pode definir limites de IDs na blacklist.\n"
        "Clique no botão abaixo:\n\n"
        f"Usuário: `{usuario.name}`\n"
        f"Limite: `{limite}`"
    )

    embed = create_base_embed(usuario, "Configurações da Blacklist", descricao, ctx.guild.id)
    view = BlacklistConfigView(bot, usuario)

    if isinstance(ctx, discord.Interaction):
        if not ctx.response.is_done():
            await ctx.response.send_message(embed=embed, view=view, ephemeral=True)
        else:
            await ctx.followup.send(embed=embed, view=view, ephemeral=True)
    else:
        await ctx.send(embed=embed, view=view)


async def exibir_embed_blacklist_aplicar(ctx, bot):
    usuario = ctx.author if hasattr(ctx, "author") else ctx.user
    data = load_blacklist()
    guild_data = data.get(str(ctx.guild.id), {"ids": {}, "limites": {}})
    limite = guild_data.get("limites", {}).get(str(usuario.id), "Não definido")

    descricao = (
        "Adicione, remova ou **liste apenas os IDs que você aplicou** na blacklist.\n\n"
        f"Usuário: `{usuario.name}`\n"
        f"Limite: `{limite}`"
    )

    embed = create_base_embed(usuario, "Gerenciamento de Blacklist", descricao, ctx.guild.id)
    view = BlacklistGerenciamentoView(bot, usuario)

    if isinstance(ctx, discord.Interaction):
        if not ctx.response.is_done():
            await ctx.response.send_message(embed=embed, view=view, ephemeral=True)
        else:
            await ctx.followup.send(embed=embed, view=view, ephemeral=True)
    else:
        await ctx.send(embed=embed, view=view)


# -----------------------------
# Cog principal
# -----------------------------
class Blacklist(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="blconfig")
    async def blconfig(self, ctx):
        await exibir_embed_blacklist_config(ctx, self.bot)

    @commands.command(name="bl")
    async def bl(self, ctx):
        await exibir_embed_blacklist_aplicar(ctx, self.bot)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        data = load_blacklist()
        guild_data = data.get(str(member.guild.id), {"ids": {}, "limites": {}})
        if str(member.id) in guild_data.get("ids", {}):
            try:
                await member.ban(reason="Usuário na blacklist.")
            except discord.Forbidden:
                pass


async def setup(bot):
    await bot.add_cog(Blacklist(bot))
