import discord
from discord.ext import commands
import asyncio

coleiras = {}

class Coleira(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def coleira(self, ctx, usuario: discord.Member):
        if ctx.author.id == usuario.id:
            await ctx.send("Você não pode coleirar você mesmo.")
            return
        coleiras[usuario.id] = ctx.author.id
        try:
            if ctx.author.voice and ctx.author.voice.channel:
                await usuario.move_to(ctx.author.voice.channel)
            await ctx.send(f"{usuario.mention} agora está coleirado(a) a você, {ctx.author.mention}!")
        except Exception as e:
            await ctx.send(f"Erro ao mover: {e}")

    @commands.command()
    async def soltar(self, ctx, usuario: discord.Member):
        dono_id = coleiras.get(usuario.id)
        if dono_id == ctx.author.id:
            coleiras.pop(usuario.id)
            await ctx.send(f"{usuario.mention} foi solto(a) da coleira.")
        else:
            await ctx.send("Você não tem coleira com essa pessoa.")

async def setup(bot):
    await bot.add_cog(Coleira(bot))