import discord
from discord.ext import commands
from discord.ui import View, Button
import json
import os
import asyncio

CONFIG_FILE = "insta_config.json"
APARENCIA_FILE = "aparencia.json"
SOCIAIS_FILE = "sociais.json"

# Emojis customizados (os IDs que você passou)
EMOJI_CURTIDA = "<:curtida:1419762210510606396>"
EMOJI_APAGAR = "<:apagar:1419762211479621695>"
EMOJI_INSTAGRAM = "<:instagram:1419779457870332176>"
EMOJI_TIKTOK = "<:tiktok:1419779459472687175>"
EMOJI_ROBLOX = "<:roblox:1419779460458090587>"

# -----------------------------
# Utilitários de arquivo / JSON
# -----------------------------
def _ensure_file(path, default):
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(default, f, indent=4, ensure_ascii=False)

def load_json(path, default):
    _ensure_file(path, default)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_config():
    return load_json(CONFIG_FILE, {})

def save_config(data):
    save_json(CONFIG_FILE, data)

def load_aparencia():
    return load_json(APARENCIA_FILE, {"cor": 0x2F3136})

def load_sociais():
    return load_json(SOCIAIS_FILE, {})

def save_sociais(data):
    save_json(SOCIAIS_FILE, data)

# -----------------------------
# Webhook helper
# -----------------------------
async def get_or_create_webhook(channel: discord.TextChannel):
    webhooks = await channel.webhooks()
    if webhooks:
        return webhooks[0]
    return await channel.create_webhook(name="InstaWebhook")

# -----------------------------
# Feed: botões sociais (emoji-only)
# -----------------------------
def criar_botoes_sociais_emoji(user_id: int) -> View:
    sociais = load_sociais()
    user_links = sociais.get(str(user_id), {})

    view = View(timeout=None)

    # Instagram
    if user_links.get("instagram"):
        view.add_item(Button(style=discord.ButtonStyle.link, url=user_links["instagram"], emoji=EMOJI_INSTAGRAM))
    else:
        view.add_item(Button(style=discord.ButtonStyle.secondary, emoji=EMOJI_INSTAGRAM, disabled=True))

    # TikTok
    if user_links.get("tiktok"):
        view.add_item(Button(style=discord.ButtonStyle.link, url=user_links["tiktok"], emoji=EMOJI_TIKTOK))
    else:
        view.add_item(Button(style=discord.ButtonStyle.secondary, emoji=EMOJI_TIKTOK, disabled=True))

    # Roblox
    if user_links.get("roblox"):
        view.add_item(Button(style=discord.ButtonStyle.link, url=user_links["roblox"], emoji=EMOJI_ROBLOX))
    else:
        view.add_item(Button(style=discord.ButtonStyle.secondary, emoji=EMOJI_ROBLOX, disabled=True))

    return view

# -----------------------------
# View do post: curtida + apagar + sociais (emoji-only)
# -----------------------------
class InstaPostView(View):
    def __init__(self, author_id: int):
        super().__init__(timeout=None)
        self.author_id = author_id
        self.likes = 0

        # Adiciona os 3 botões de sociais (emoji-only)
        sociais_view = criar_botoes_sociais_emoji(author_id)
        for item in sociais_view.children:
            self.add_item(item)

    @discord.ui.button(label="0", style=discord.ButtonStyle.secondary, emoji=EMOJI_CURTIDA, custom_id="insta_like")
    async def like_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            await interaction.response.defer()  # evita "esta interação falhou"
        except:
            pass

        self.likes += 1
        button.label = str(self.likes)
        try:
            # ✅ Correção: edita a mensagem da interação de forma segura
            await interaction.response.edit_message(view=self)
        except Exception:
            try:
                await interaction.followup.send("Erro ao registrar like.", ephemeral=True)
            except:
                pass

    @discord.ui.button(label="", style=discord.ButtonStyle.secondary, emoji=EMOJI_APAGAR, custom_id="insta_delete")
    async def delete_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message("Apenas o autor pode apagar esta postagem.", ephemeral=True)
        try:
            await interaction.message.delete()
        except:
            try:
                await interaction.response.send_message("Não foi possível deletar a mensagem.", ephemeral=True)
            except:
                pass

# -----------------------------
# View: configuração do sistema Insta (canal + cargo)
# -----------------------------
class InstaConfigView(View):
    def __init__(self, bot, guild_id):
        super().__init__(timeout=None)
        self.bot = bot
        self.guild_id = guild_id

    @discord.ui.button(label="Definir Canal", style=discord.ButtonStyle.primary, custom_id="insta_set_channel")
    async def set_channel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user is None:
            return
        await interaction.response.send_message("Mencione o canal que será usado para o Insta (ex: #canal):", ephemeral=True)

        def check(m):
            return m.author.id == interaction.user.id and m.channel == interaction.channel and len(m.channel_mentions) > 0

        try:
            msg = await self.bot.wait_for("message", timeout=30, check=check)
            canal = msg.channel_mentions[0]

            cfg = load_config()
            cfg[str(interaction.guild.id)] = cfg.get(str(interaction.guild.id), {})
            cfg[str(interaction.guild.id)]["channel_id"] = canal.id
            save_config(cfg)

            await msg.delete()
            await interaction.followup.send(f"Canal configurado: {canal.mention}", ephemeral=True)
        except asyncio.TimeoutError:
            await interaction.followup.send("Tempo esgotado para definir canal.", ephemeral=True)

    @discord.ui.button(label="Definir Cargo", style=discord.ButtonStyle.secondary, custom_id="insta_set_role")
    async def set_role(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user is None:
            return
        await interaction.response.send_message("Mencione o cargo que terá permissão para postar no Insta:", ephemeral=True)

        def check(m):
            return m.author.id == interaction.user.id and m.channel == interaction.channel and len(m.role_mentions) > 0

        try:
            msg = await self.bot.wait_for("message", timeout=30, check=check)
            role = msg.role_mentions[0]

            cfg = load_config()
            cfg[str(interaction.guild.id)] = cfg.get(str(interaction.guild.id), {})
            cfg[str(interaction.guild.id)]["role_id"] = role.id
            save_config(cfg)

            await msg.delete()
            await interaction.followup.send(f"Cargo configurado: {role.mention}", ephemeral=True)
        except asyncio.TimeoutError:
            await interaction.followup.send("Tempo esgotado para definir cargo.", ephemeral=True)

# -----------------------------
# Função chamada pelo painel (abre embed insta config)
# -----------------------------
async def exibir_embed_insta_config(interaction: discord.Interaction, bot):
    cfg = load_config()
    apar = load_aparencia()
    cor = apar.get("cor", 0x2F3136)

    guild_cfg = cfg.get(str(interaction.guild.id), {})
    role_id = guild_cfg.get("role_id")
    channel_id = guild_cfg.get("channel_id")

    cargo = interaction.guild.get_role(role_id) if role_id else None
    canal = interaction.guild.get_channel(channel_id) if channel_id else None

    embed = discord.Embed(
        title="Configuração do Instagram",
        description=(
            f"Canal: {canal.mention if canal else '`Nenhum definido`'}\n"
            f"Cargo: {cargo.mention if cargo else '`Nenhum definido`'}"
        ),
        color=cor
    )
    embed.set_footer(text=f"Configuração solicitada por {interaction.user.name}")

    view = InstaConfigView(bot, interaction.guild.id)
    await interaction.followup.send(embed=embed, view=view, ephemeral=True)

# -----------------------------
# View: configuração de sociais por usuário
# -----------------------------
class SociaisConfigView(View):
    def __init__(self, user: discord.User):
        super().__init__(timeout=None)
        self.user = user

    @discord.ui.button(emoji=EMOJI_INSTAGRAM, style=discord.ButtonStyle.secondary, custom_id="cfg_insta")
    async def set_instagram(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("Apenas você pode editar suas sociais.", ephemeral=True)

        await interaction.response.send_message("Envie o link do seu Instagram (cole o URL):", ephemeral=True)

        def check(m):
            return m.author.id == interaction.user.id and m.channel == interaction.channel

        try:
            msg = await interaction.client.wait_for("message", timeout=120, check=check)
            link = msg.content.strip()
            sociais = load_sociais()
            sociais[str(self.user.id)] = sociais.get(str(self.user.id), {})
            sociais[str(self.user.id)]["instagram"] = link
            save_sociais(sociais)
            await msg.delete()
            await interaction.message.edit(embed=_build_embed_sociais(self.user), view=self)
            await interaction.followup.send("Instagram salvo com sucesso!", ephemeral=True)
        except asyncio.TimeoutError:
            await interaction.followup.send("Tempo esgotado para enviar o link.", ephemeral=True)

    @discord.ui.button(emoji=EMOJI_TIKTOK, style=discord.ButtonStyle.secondary, custom_id="cfg_tiktok")
    async def set_tiktok(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("Apenas você pode editar suas sociais.", ephemeral=True)

        await interaction.response.send_message("Envie o link do seu TikTok (cole o URL):", ephemeral=True)

        def check(m):
            return m.author.id == interaction.user.id and m.channel == interaction.channel

        try:
            msg = await interaction.client.wait_for("message", timeout=120, check=check)
            link = msg.content.strip()
            sociais = load_sociais()
            sociais[str(self.user.id)] = sociais.get(str(self.user.id), {})
            sociais[str(self.user.id)]["tiktok"] = link
            save_sociais(sociais)
            await msg.delete()
            await interaction.message.edit(embed=_build_embed_sociais(self.user), view=self)
            await interaction.followup.send("TikTok salvo com sucesso!", ephemeral=True)
        except asyncio.TimeoutError:
            await interaction.followup.send("Tempo esgotado para enviar o link.", ephemeral=True)

    @discord.ui.button(emoji=EMOJI_ROBLOX, style=discord.ButtonStyle.secondary, custom_id="cfg_roblox")
    async def set_roblox(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("Apenas você pode editar suas sociais.", ephemeral=True)

        await interaction.response.send_message("Envie o link do seu Roblox (cole o URL):", ephemeral=True)

        def check(m):
            return m.author.id == interaction.user.id and m.channel == interaction.channel

        try:
            msg = await interaction.client.wait_for("message", timeout=120, check=check)
            link = msg.content.strip()
            sociais = load_sociais()
            sociais[str(self.user.id)] = sociais.get(str(self.user.id), {})
            sociais[str(self.user.id)]["roblox"] = link
            save_sociais(sociais)
            await msg.delete()
            await interaction.message.edit(embed=_build_embed_sociais(self.user), view=self)
            await interaction.followup.send("Roblox salvo com sucesso!", ephemeral=True)
        except asyncio.TimeoutError:
            await interaction.followup.send("Tempo esgotado para enviar o link.", ephemeral=True)

# -----------------------------
# Helpers para o painel de sociais
# -----------------------------
def _build_embed_sociais(user: discord.User) -> discord.Embed:
    apar = load_aparencia()
    cor = apar.get("cor", 0x2F3136)
    sociais = load_sociais()
    user_data = sociais.get(str(user.id), {})

    insta = user_data.get("instagram", "`Não configurado`")
    tiktok = user_data.get("tiktok", "`Não configurado`")
    roblox = user_data.get("roblox", "`Não configurado`")

    embed = discord.Embed(
        title="Suas Redes Sociais",
        description=f"{EMOJI_INSTAGRAM} {insta}\n{EMOJI_TIKTOK} {tiktok}\n{EMOJI_ROBLOX} {roblox}",
        color=cor
    )
    embed.set_footer(text=f"Configuração de {user.name}")
    return embed

async def _auto_delete_message(msg: discord.Message, delay: int = 300):
    await asyncio.sleep(delay)
    try:
        await msg.delete()
    except:
        pass

# -----------------------------
# Função que abre painel de sociais (c!sociais)
# -----------------------------
async def exibir_embed_sociais_cmd(ctx: commands.Context):
    try:
        await ctx.message.delete()
    except:
        pass

    embed = _build_embed_sociais(ctx.author)
    view = SociaisConfigView(ctx.author)
    msg = await ctx.send(embed=embed, view=view)
    asyncio.create_task(_auto_delete_message(msg, 300))

# -----------------------------
# Cog principal
# -----------------------------
class InstaConfig(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or message.guild is None:
            return

        cfg = load_config()
        guild_cfg = cfg.get(str(message.guild.id), {})
        channel_id = guild_cfg.get("channel_id")
        role_id = guild_cfg.get("role_id")

        if not channel_id or not role_id:
            return

        if message.channel.id != channel_id:
            return

        role = message.guild.get_role(role_id)
        if not role or role not in message.author.roles:
            try:
                await message.delete()
            except:
                pass
            return

        if message.attachments:
            canal = message.channel
            webhook = await get_or_create_webhook(canal)
            view = InstaPostView(author_id=message.author.id)
            files = [await att.to_file() for att in message.attachments]

            try:
                await webhook.send(
                    content=f"{message.author.mention}\n{message.content or ''}",
                    username=message.author.display_name,
                    avatar_url=message.author.display_avatar.url,
                    files=files,
                    view=view,
                    wait=True
                )
            except Exception:
                try:
                    await message.channel.send(content=f"{message.author.mention}\n{message.content or ''}", files=files, view=view)
                except:
                    pass

        try:
            await message.delete()
        except:
            pass

    @commands.command(name="sociais")
    async def sociais_cmd(self, ctx: commands.Context):
        await exibir_embed_sociais_cmd(ctx)

# -----------------------------
# Setup
# -----------------------------
async def setup(bot):
    await bot.add_cog(InstaConfig(bot))
