# extensoes/backup.py
import discord
from discord.ext import commands
from discord.ui import View, Button
import json
import os
import asyncio

CONFIG_FILE = "backup.json"
APARENCIA_FILE = "aparencia.json"


# -------------------------
# FUNÇÕES DE BACKUP
# -------------------------
def load_backup():
    if not os.path.exists(CONFIG_FILE):
        data = {"status": False, "backup": False, "log_channel": None, "data": {}}
        save_backup(data)
        return data
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_backup(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def get_color(guild_id: int) -> discord.Color:
    if not os.path.exists(APARENCIA_FILE):
        return discord.Color(0x2f3136)

    with open(APARENCIA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)

    guild_data = data.get(str(guild_id))
    if guild_data and "cor" in guild_data:
        try:
            return discord.Color(int(guild_data["cor"].replace("#", ""), 16))
        except ValueError:
            return discord.Color(0x2f3136)
    return discord.Color(0x2f3136)


# -------------------------
# VIEW DO PAINEL
# -------------------------
class BackupView(View):
    def __init__(self, backup_data):
        super().__init__(timeout=None)
        self.backup_data = backup_data

        # Botão Ativar/Desativar
        status = "Desativar" if backup_data["status"] else "Ativar"
        color = discord.ButtonStyle.green if not backup_data["status"] else discord.ButtonStyle.red
        self.add_item(Button(label=status, style=color, custom_id="toggle_backup"))

        # Botão Criar Backup
        self.add_item(Button(label="Criar Backup", style=discord.ButtonStyle.blurple, custom_id="create_backup"))

        # Botão Definir Logs
        self.add_item(Button(label="Definir Logs", style=discord.ButtonStyle.gray, custom_id="set_logs"))

    def make_embed(self, guild_id: int):
        status_txt = "ativado" if self.backup_data["status"] else "desativado"
        backup_txt = "criado" if self.backup_data["backup"] else "não criado"
        log_txt = f"<#{self.backup_data['log_channel']}>" if self.backup_data["log_channel"] else "não definido"

        embed = discord.Embed(title="Sistema de Backup", color=get_color(guild_id))
        embed.add_field(name="Status", value=f"``{status_txt}``", inline=False)
        embed.add_field(name="Backup", value=f"``{backup_txt}``", inline=False)
        embed.add_field(name="Canal de Logs", value=f"``{log_txt}``", inline=False)
        return embed


# -------------------------
# EXTENSÃO
# -------------------------
class Backup(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if not interaction.data.get("custom_id"):
            return

        data = load_backup()

        if interaction.data["custom_id"] == "toggle_backup":
            data["status"] = not data["status"]
            save_backup(data)
            await interaction.response.edit_message(embed=BackupView(data).make_embed(interaction.guild.id), view=BackupView(data))

        elif interaction.data["custom_id"] == "create_backup":
            guild = interaction.guild
            data["backup"] = True

            # Salvar cargos
            cargos = []
            for role in guild.roles:
                if role.is_default():
                    continue
                membros = [member.id for member in role.members]
                cargos.append({
                    "id": role.id,
                    "name": role.name,
                    "permissions": role.permissions.value,
                    "color": role.color.value,
                    "hoist": role.hoist,
                    "mentionable": role.mentionable,
                    "position": role.position,
                    "members": membros
                })

            # Salvar canais e categorias
            canais = []
            for channel in guild.channels:
                canal_info = {
                    "id": channel.id,
                    "name": channel.name,
                    "type": str(channel.type),
                    "position": channel.position,
                    "category": channel.category.id if channel.category else None,
                    "overwrites": {}
                }
                for target, overwrite in channel.overwrites.items():
                    canal_info["overwrites"][str(target.id)] = overwrite._values
                canais.append(canal_info)

            data["data"] = {"roles": cargos, "channels": canais}
            save_backup(data)

            await interaction.response.edit_message(embed=BackupView(data).make_embed(guild.id), view=BackupView(data))

        elif interaction.data["custom_id"] == "set_logs":
            await interaction.response.send_message(
                "Por favor, mencione o canal para definir como canal de logs.", ephemeral=True
            )

            def check(msg):
                return msg.author == interaction.user and msg.channel == interaction.channel and len(msg.channel_mentions) > 0

            try:
                msg = await self.bot.wait_for("message", check=check, timeout=60)
                log_channel = msg.channel_mentions[0]
                data["log_channel"] = log_channel.id
                save_backup(data)
                await interaction.followup.send(f"Canal de logs definido para {log_channel.mention}.", ephemeral=True)
                await interaction.message.edit(embed=BackupView(data).make_embed(interaction.guild.id), view=BackupView(data))
            except asyncio.TimeoutError:
                await interaction.followup.send("Tempo esgotado. Canal de logs não definido.", ephemeral=True)

    async def log_action(self, guild, title, description, user: discord.Member = None):
        data = load_backup()
        if not data["log_channel"]:
            return
        log_ch = guild.get_channel(data["log_channel"])
        if not log_ch:
            return
        embed = discord.Embed(title=title, description=description, color=get_color(guild.id))
        if user:
            embed.set_footer(text=f"Ação feita por {user} (ID: {user.id})")
        await log_ch.send(embed=embed)

    async def get_audit_user(self, guild, action: discord.AuditLogAction):
        await asyncio.sleep(1)
        async for entry in guild.audit_logs(limit=1, action=action):
            return entry.user
        return None

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        data = load_backup()
        if data["status"] and data["backup"]:
            guild = channel.guild
            user = await self.get_audit_user(guild, discord.AuditLogAction.channel_delete)
            for c in data["data"]["channels"]:
                if c["id"] == channel.id:
                    if c["type"] == "category":
                        await guild.create_category(c["name"], position=c["position"])
                    elif c["type"] == "text":
                        parent = guild.get_channel(c["category"]) if c["category"] else None
                        await guild.create_text_channel(c["name"], category=parent, position=c["position"])
                    elif c["type"] == "voice":
                        parent = guild.get_channel(c["category"]) if c["category"] else None
                        await guild.create_voice_channel(c["name"], category=parent, position=c["position"])
                    await self.log_action(
                        guild, "Canal restaurado",
                        f"O canal/categoria **{c['name']}** foi recriado após exclusão.",
                        user=user
                    )
                    break

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before, after):
        data = load_backup()
        if data["status"] and data["backup"]:
            guild = before.guild
            user = await self.get_audit_user(guild, discord.AuditLogAction.channel_update)
            for c in data["data"]["channels"]:
                if c["id"] == before.id:
                    if after.name != c["name"] or after.position != c["position"]:
                        await after.edit(name=c["name"], position=c["position"])
                        await self.log_action(
                            guild, "Canal restaurado",
                            f"O canal **{before.name}** foi restaurado para **{c['name']}** (posição {c['position']}).",
                            user=user
                        )
                    break

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        data = load_backup()
        if data["status"] and data["backup"]:
            guild = role.guild
            user = await self.get_audit_user(guild, discord.AuditLogAction.role_delete)
            for r in data["data"]["roles"]:
                if r["id"] == role.id:
                    new_role = await guild.create_role(
                        name=r["name"],
                        permissions=discord.Permissions(r["permissions"]),
                        color=discord.Color(r["color"]),
                        hoist=r["hoist"],
                        mentionable=r["mentionable"]
                    )
                    await new_role.edit(position=r["position"])
                    # Atribuir aos membros antigos
                    for member_id in r.get("members", []):
                        member = guild.get_member(member_id)
                        if member:
                            await member.add_roles(new_role)
                    await self.log_action(
                        guild, "Cargo recriado",
                        f"O cargo **{r['name']}** foi recriado após exclusão e atribuído aos membros antigos.",
                        user=user
                    )
                    break

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        data = load_backup()
        if data["status"] and data["backup"]:
            guild = before.guild
            user = await self.get_audit_user(guild, discord.AuditLogAction.role_update)
            for r in data["data"]["roles"]:
                if r["id"] == before.id:
                    if (after.permissions.value != r["permissions"] or
                        after.color.value != r["color"] or
                        after.hoist != r["hoist"] or
                        after.mentionable != r["mentionable"]):
                        await after.edit(
                            name=r["name"],
                            permissions=discord.Permissions(r["permissions"]),
                            color=discord.Color(r["color"]),
                            hoist=r["hoist"],
                            mentionable=r["mentionable"]
                        )
                        await self.log_action(
                            guild, "Cargo restaurado",
                            f"O cargo **{before.name}** foi restaurado para configuração original.",
                            user=user
                        )
                    break


async def setup(bot):
    await bot.add_cog(Backup(bot))


# Função extra para abrir embed pelo painel
async def exibir_embed_backup(interaction, bot):
    data = load_backup()
    view = BackupView(data)
    embed = view.make_embed(interaction.guild.id)
    await interaction.response.edit_message(embed=embed, view=view)
