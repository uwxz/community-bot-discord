import discord
from discord.ext import commands
import json
import os
import asyncio

CONFIG_FILE = "config.json"
APARENCIA_FILE = "aparencia.json"


# ------------------------------
# Funções utilitárias
# ------------------------------
def carregar_config():
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "w") as f:
            json.dump({}, f)
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)


def salvar_config(dados):
    with open(CONFIG_FILE, "w") as f:
        json.dump(dados, f, indent=4)


def cor_aparencia(guild_id):
    try:
        with open(APARENCIA_FILE, "r") as f:
            dados = json.load(f)
        return discord.Color.from_str(dados.get(str(guild_id), {}).get("cor", "#2f3136"))
    except:
        return discord.Color.from_str("#2f3136")


# ------------------------------
# Exibir e editar painel
# ------------------------------
async def exibir_embed_antibot(ctx):
    config = carregar_config()
    gid = str(ctx.guild.id)

    if gid not in config:
        config[gid] = {"ativo": False, "log_externo": None}
        salvar_config(config)

    ativo = config[gid]["ativo"]
    log_externo_id = config[gid]["log_externo"]
    canal_externo_mention = f"<#{log_externo_id}>" if log_externo_id else "Nenhum definido"
    status = "Ativado " if ativo else "Desativado "

    embed = discord.Embed(
        title="Painel AntiBot",
        description="Configure a proteção contra bots no servidor.",
        color=cor_aparencia(ctx.guild.id)
    )
    embed.add_field(name="Status", value=status, inline=True)
    embed.add_field(name="Canal de Logs Externo", value=canal_externo_mention, inline=True)
    embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else None)

    view = AntibotView(ctx, config, ativo)
    await ctx.send(embed=embed, view=view)


async def editar_embed_antibot(msg, ctx, config):
    gid = str(ctx.guild.id)
    if gid not in config:
        config[gid] = {"ativo": False, "log_externo": None}

    ativo = config[gid]["ativo"]
    log_externo_id = config[gid]["log_externo"]
    canal_externo_mention = f"<#{log_externo_id}>" if log_externo_id else "Nenhum definido"
    status = "Ativado " if ativo else "Desativado "

    embed = discord.Embed(
        title="Painel AntiBot",
        description="Configure a proteção contra bots no servidor.",
        color=cor_aparencia(ctx.guild.id)
    )
    embed.add_field(name="Status", value=status, inline=True)
    embed.add_field(name="Canal de Logs Externo", value=canal_externo_mention, inline=True)
    embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else None)

    view = AntibotView(ctx, config, ativo)
    await msg.edit(embed=embed, view=view)


# ------------------------------
# Views e Botões
# ------------------------------
class AntibotView(discord.ui.View):
    def __init__(self, ctx, config, ativo):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.config = config
        self.guild_id = str(ctx.guild.id)
        self.ativo = ativo

        if self.ativo:
            self.add_item(BotaoDesativar(self.ctx, self.config))
        else:
            self.add_item(BotaoAtivar(self.ctx, self.config))

        self.add_item(BotaoDefinirLogsExterno(self.ctx, self.config))


class BotaoAtivar(discord.ui.Button):
    def __init__(self, ctx, config):
        super().__init__(label="Ativar", style=discord.ButtonStyle.success)
        self.ctx = ctx
        self.config = config

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message(
                "Apenas quem usou o comando pode usar os botões.",
                ephemeral=True
            )

        await interaction.response.defer(ephemeral=True)
        gid = str(self.ctx.guild.id)
        self.config.setdefault(gid, {"ativo": False, "log_externo": None})
        self.config[gid]["ativo"] = True
        salvar_config(self.config)

        await editar_embed_antibot(interaction.message, self.ctx, self.config)
        await interaction.followup.send(" AntiBot ativado.", ephemeral=True)


class BotaoDesativar(discord.ui.Button):
    def __init__(self, ctx, config):
        super().__init__(label="Desativar", style=discord.ButtonStyle.danger)
        self.ctx = ctx
        self.config = config

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message(
                "Apenas quem usou o comando pode usar os botões.",
                ephemeral=True
            )

        await interaction.response.defer(ephemeral=True)
        gid = str(self.ctx.guild.id)
        self.config.setdefault(gid, {"ativo": False, "log_externo": None})
        self.config[gid]["ativo"] = False
        salvar_config(self.config)

        await editar_embed_antibot(interaction.message, self.ctx, self.config)
        await interaction.followup.send(" AntiBot desativado.", ephemeral=True)


class BotaoDefinirLogsExterno(discord.ui.Button):
    def __init__(self, ctx, config):
        super().__init__(label="Definir Log Externo", style=discord.ButtonStyle.secondary)
        self.ctx = ctx
        self.config = config

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message(
                "Apenas quem usou o comando pode usar os botões.",
                ephemeral=True
            )

        await interaction.response.send_message(
            "Mencione o canal de logs externo (ex.: `#logs`):",
            ephemeral=True
        )

        def check(m):
            return (
                m.author == self.ctx.author
                and m.channel == getattr(self.ctx, "channel", None)
                and len(m.channel_mentions) > 0
            )

        try:
            msg = await self.ctx.bot.wait_for("message", check=check, timeout=30)
            canal = msg.channel_mentions[0]
            self.config.setdefault(str(self.ctx.guild.id), {"ativo": False, "log_externo": None})
            self.config[str(self.ctx.guild.id)]["log_externo"] = canal.id
            salvar_config(self.config)
            await msg.delete()

            await editar_embed_antibot(interaction.message, self.ctx, self.config)
            await interaction.followup.send(f" Canal de logs externo definido para {canal.mention}.", ephemeral=True)
        except asyncio.TimeoutError:
            await interaction.followup.send(" Tempo esgotado ou canal inválido.", ephemeral=True)


# ------------------------------
# Cog principal
# ------------------------------
class AntiBot(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = carregar_config()

    @commands.command()
    async def antibot(self, ctx):
        await exibir_embed_antibot(ctx)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if not member.bot:
            return

        config = carregar_config()
        gid = str(member.guild.id)
        guild_conf = config.get(gid, {})

        if not guild_conf.get("ativo"):
            return

        me = member.guild.me
        if me is None or not me.guild_permissions.kick_members:
            print(f"[AntiBot] Sem permissão de expulsar no servidor {member.guild.id}")
            return

        try:
            await member.kick(reason="Bot detectado - AntiBot")
        except Exception as e:
            print(f"Erro ao expulsar bot: {e}")
            return

        # -------------------
        # LOG BONITINHO
        # -------------------
        canal_id = guild_conf.get("log_externo")
        if canal_id:
            canal = self.bot.get_channel(canal_id)
            if canal:
                embed = discord.Embed(
                    title=" AntiBot • Bot Expulso",
                    description="Um bot foi detectado e expulso automaticamente do servidor.",
                    color=discord.Color.red(),
                    timestamp=discord.utils.utcnow()
                )
                embed.add_field(name=" Bot", value=f"{member.mention}\n`{member}`", inline=True)
                embed.add_field(name=" ID", value=f"`{member.id}`", inline=True)
                embed.add_field(
                    name=" Data/Hora",
                    value=f"<t:{int(discord.utils.utcnow().timestamp())}:F>",
                    inline=False
                )
                embed.set_thumbnail(
                    url=member.display_avatar.url if getattr(member, 'display_avatar', None) else None
                )
                embed.set_footer(
                    text=f"Servidor: {member.guild.name}",
                    icon_url=member.guild.icon.url if member.guild.icon else None
                )
                await canal.send(embed=embed)


# ------------------------------
# Setup
# ------------------------------
async def setup(bot):
    await bot.add_cog(AntiBot(bot))
