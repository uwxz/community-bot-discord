import discord
from discord.ext import commands
import json
import asyncio
import os

APARENCIA_FILE = "aparencia.json"

def carregar_aparencia():
    if not os.path.exists(APARENCIA_FILE):
        with open(APARENCIA_FILE, "w") as f:
            json.dump({}, f)
    with open(APARENCIA_FILE, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            print(f" Erro ao carregar {APARENCIA_FILE}. Verifique a formatação.")
            return {}

def salvar_aparencia(data):
    with open(APARENCIA_FILE, "w") as f:
        json.dump(data, f, indent=4)

aparencia = carregar_aparencia()

# Embed reutilizável para o painel
async def exibir_embed_aparencia(ctx):
    gid = str(ctx.guild.id)
    conf = aparencia.setdefault(gid, {"cor": "#2f3136", "prefixo": "!"})
    salvar_aparencia(aparencia)

    embed = discord.Embed(
        title=f"Painel de Configurações do Bot – {ctx.guild.name}",
        description=f"Administrador(a): {ctx.author.mention}",
        color=discord.Color.from_str(conf.get("cor", "#2f3136"))
    )
    embed.add_field(
        name="Informações do Bot",
        value=f"Prefixo: `{conf.get('prefixo', '!')}`\nCor: `{conf.get('cor', '(padrão)')}`",
        inline=False
    )
    embed.set_footer(text=f"Página: Aparência • Hoje às {ctx.message.created_at.strftime('%H:%M')}")
    embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else ctx.bot.user.display_avatar.url)

    await ctx.send(embed=embed, view=AparenciaView(ctx))

class Aparencia(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def aparencia(self, ctx):
        if not hasattr(self.bot, "permissoes"):
            self.bot.permissoes = set()
        if ctx.author.id not in self.bot.permissoes and ctx.author.id != self.bot.MEU_ID:
            return await ctx.send("Você não tem permissão para usar este comando.")
        await exibir_embed_aparencia(ctx)

class AparenciaView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=60)
        self.ctx = ctx

    @discord.ui.button(label="Alterar Prefixo", style=discord.ButtonStyle.primary)
    async def alterar_prefixo(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas quem executou o comando pode alterar.", ephemeral=True)

        await interaction.response.send_message("Qual será o novo prefixo?", ephemeral=True)

        def check(m): return m.author == self.ctx.author and m.channel == self.ctx.channel
        try:
            msg = await self.ctx.bot.wait_for("message", check=check, timeout=30)
            novo = msg.content.strip()
            if len(novo) > 3:
                return await self.ctx.send("O prefixo deve ter até 3 caracteres.", delete_after=5)
            aparencia.setdefault(str(self.ctx.guild.id), {})["prefixo"] = novo
            salvar_aparencia(aparencia)
            await msg.delete()
            await self.ctx.send(f"Prefixo atualizado para `{novo}`", delete_after=5)
        except asyncio.TimeoutError:
            await self.ctx.send("Tempo esgotado.", delete_after=5)

    @discord.ui.button(label="Alterar Cor Embed", style=discord.ButtonStyle.primary)
    async def alterar_cor(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas quem executou o comando pode alterar.", ephemeral=True)

        await interaction.response.send_message("Escolha uma cor abaixo:", view=CorEmbedMenu(interaction.guild.id), ephemeral=True)

    @discord.ui.button(label="Alterar Nickname", style=discord.ButtonStyle.secondary)
    async def alterar_nick(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas quem executou o comando pode alterar.", ephemeral=True)
        await interaction.response.send_message("Qual será o novo nome do bot?", ephemeral=True)

        def check(m): return m.author == self.ctx.author and m.channel == self.ctx.channel
        try:
            msg = await self.ctx.bot.wait_for("message", check=check, timeout=30)
            novo_nome = msg.content.strip()
            await self.ctx.guild.me.edit(nick=novo_nome)
            await msg.delete()
            await self.ctx.send(f"Nickname atualizado para `{novo_nome}`", delete_after=5)
        except asyncio.TimeoutError:
            await self.ctx.send("Tempo esgotado.", delete_after=5)

    @discord.ui.button(label="Alterar Avatar", style=discord.ButtonStyle.secondary)
    async def alterar_avatar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas quem executou o comando pode alterar.", ephemeral=True)
        await interaction.response.send_message("Envie a imagem para o novo avatar do bot.", ephemeral=True)

        def check(m): return m.author == self.ctx.author and m.channel == self.ctx.channel and m.attachments
        try:
            msg = await self.ctx.bot.wait_for("message", check=check, timeout=30)
            imagem = await msg.attachments[0].read()
            await self.ctx.bot.user.edit(avatar=imagem)
            await msg.delete()
            await self.ctx.send("Avatar do bot alterado com sucesso.", delete_after=5)
        except asyncio.TimeoutError:
            await self.ctx.send("Tempo esgotado.", delete_after=5)

class CorEmbedMenu(discord.ui.View):
    def __init__(self, guild_id):
        super().__init__(timeout=60)
        self.guild_id = str(guild_id)

    @discord.ui.select(
        placeholder="Utilize este menu para ver outras cores.",
        options=[
            discord.SelectOption(label="Preto", value="#2f3136"),
            discord.SelectOption(label="Branco", value="#ffffff"),
            discord.SelectOption(label="Vermelho", value="#ed4245"),
            discord.SelectOption(label="Azul Escuro", value="#0c1446"),
            discord.SelectOption(label="Azul Cyan", value="#00bcd4"),
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        aparencia[self.guild_id]["cor"] = select.values[0]
        salvar_aparencia(aparencia)
        await interaction.response.send_message(f"Cor das embeds definida para `{select.values[0]}`", ephemeral=True)

# Função obrigatória da extensão
async def setup(bot):
    if not bot.get_cog("Aparencia"):
        await bot.add_cog(Aparencia(bot))
