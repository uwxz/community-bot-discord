import discord
from discord.ext import commands
from discord.ui import View, Button, Select
import json
import os

# -----------------------------
# Configurações
# -----------------------------
DATA_FILE = "protecaocargos.json"
APARENCIA_FILE = "aparencia.json"

EMOJI_ATIVADO = "<a:ativado:1183156035721113681>"
EMOJI_DESATIVADO = "<a:desativado:1183155978871525417>"

# -----------------------------
# Funções utilitárias
# -----------------------------
def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def ensure_defaults(guild_id: str, data: dict):
    if guild_id not in data:
        data[guild_id] = {"ativado": False, "cargos": []}
    if "ativado" not in data[guild_id]:
        data[guild_id]["ativado"] = False
    if "cargos" not in data[guild_id]:
        data[guild_id]["cargos"] = []
    return data


def get_embed_color():
    if not os.path.exists(APARENCIA_FILE):
        return discord.Color.dark_gray()
    with open(APARENCIA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
        cor_hex = data.get("cor", "#2f3136")
        return discord.Color(int(cor_hex.replace("#", ""), 16))

# -----------------------------
# View principal
# -----------------------------
class ProtecaoCargosView(View):
    def __init__(self):
        super().__init__(timeout=None)

        self.add_item(ToggleProtecaoButton())
        self.add_item(AddCargoButton())
        self.add_item(RemoveCargoButton())
        self.add_item(ListarCargosButton())


# -----------------------------
# Botões
# -----------------------------
class ToggleProtecaoButton(Button):
    def __init__(self):
        super().__init__(style=discord.ButtonStyle.green, label="Carregando...", custom_id="toggle_protecao")

    async def callback(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        data = load_data()
        data = ensure_defaults(guild_id, data)
        guild_data = data[guild_id]

        # Alterna estado
        guild_data["ativado"] = not guild_data["ativado"]
        save_data(data)

        await exibir_embed_protecao_cargos(interaction, interaction.client)


class AddCargoButton(Button):
    def __init__(self):
        super().__init__(style=discord.ButtonStyle.blurple, label="Adicionar Cargo Protegido", custom_id="add_cargo")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_message("Mencione o cargo que deseja adicionar à proteção.", ephemeral=True)

        def check(msg):
            return msg.author == interaction.user and msg.channel == interaction.channel

        try:
            msg = await interaction.client.wait_for("message", check=check, timeout=60)
        except:
            return await interaction.followup.send("Tempo esgotado.", ephemeral=True)

        if not msg.role_mentions:
            return await interaction.followup.send("Você precisa mencionar um cargo válido.", ephemeral=True)

        role = msg.role_mentions[0]
        guild_id = str(interaction.guild.id)
        data = load_data()
        data = ensure_defaults(guild_id, data)
        guild_data = data[guild_id]

        if role.id not in guild_data["cargos"]:
            guild_data["cargos"].append(role.id)
            save_data(data)

        await exibir_embed_protecao_cargos(interaction, interaction.client)


class RemoveCargoButton(Button):
    def __init__(self):
        super().__init__(style=discord.ButtonStyle.red, label="Remover Cargos Protegidos", custom_id="remove_cargo")

    async def callback(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        data = load_data()
        data = ensure_defaults(guild_id, data)
        guild_data = data[guild_id]

        if not guild_data["cargos"]:
            return await interaction.response.send_message("Não há cargos protegidos.", ephemeral=True)

        options = [discord.SelectOption(label=interaction.guild.get_role(c).name, value=str(c)) for c in guild_data["cargos"] if interaction.guild.get_role(c)]
        if not options:
            return await interaction.response.send_message("Nenhum cargo válido encontrado.", ephemeral=True)

        select = Select(placeholder="Selecione cargos para remover", min_values=1, max_values=len(options), options=options)

        async def select_callback(select_interaction: discord.Interaction):
            removidos = []
            for cargo_id in select.values:
                if int(cargo_id) in guild_data["cargos"]:
                    guild_data["cargos"].remove(int(cargo_id))
                    removidos.append(interaction.guild.get_role(int(cargo_id)).mention)

            save_data(data)
            await select_interaction.response.send_message(f"Cargos removidos: {', '.join(removidos)}", ephemeral=True)
            await exibir_embed_protecao_cargos(interaction, interaction.client)

        select.callback = select_callback
        view = View()
        view.add_item(select)

        await interaction.response.send_message("Selecione os cargos que deseja remover:", view=view, ephemeral=True)


class ListarCargosButton(Button):
    def __init__(self):
        super().__init__(style=discord.ButtonStyle.gray, label="Listar Cargos", custom_id="listar_cargos")

    async def callback(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        data = load_data()
        data = ensure_defaults(guild_id, data)
        guild_data = data[guild_id]

        cargos_protegidos = guild_data.get("cargos", [])
        cargos_txt = "Nenhum cargo protegido." if not cargos_protegidos else "\n".join(
            f"<@&{cargo_id}>" for cargo_id in cargos_protegidos
        )

        await interaction.response.send_message(f"Cargos protegidos:\n{cargos_txt}", ephemeral=True)


# -----------------------------
# Função para exibir embed
# -----------------------------
async def exibir_embed_protecao_cargos(interaction: discord.Interaction, bot: commands.Bot):
    guild_id = str(interaction.guild.id)
    data = load_data()
    data = ensure_defaults(guild_id, data)
    guild_data = data[guild_id]

    embed = discord.Embed(
        title="Proteção de Cargos",
        description="Gerencie a proteção contra alterações de cargos.",
        color=get_embed_color()
    )

    cargos_protegidos = guild_data.get("cargos", [])
    cargos_txt = "Nenhum cargo protegido." if not cargos_protegidos else "\n".join(
        f"<@&{cargo_id}>" for cargo_id in cargos_protegidos
    )
    embed.add_field(name="Cargos Protegidos", value=cargos_txt, inline=False)

    # Atualizar botão toggle
    view = ProtecaoCargosView()
    for item in view.children:
        if isinstance(item, ToggleProtecaoButton):
            if guild_data["ativado"]:
                item.label = "Desativar Proteção"
                item.emoji = EMOJI_ATIVADO
                item.style = discord.ButtonStyle.red
            else:
                item.label = "Ativar Proteção"
                item.emoji = EMOJI_DESATIVADO
                item.style = discord.ButtonStyle.green

    await interaction.response.edit_message(embed=embed, view=view)


# -----------------------------
# Evento: proteger cargos
# -----------------------------
async def verificar_alteracoes(bot, before: discord.Member, after: discord.Member):
    if before.roles == after.roles:
        return

    guild_id = str(after.guild.id)
    data = load_data()
    data = ensure_defaults(guild_id, data)
    guild_data = data[guild_id]

    if not guild_data["ativado"]:
        return

    cargos_protegidos = guild_data.get("cargos", [])
    if not cargos_protegidos:
        return

    # Verificar se algum cargo protegido foi adicionado sem permissão
    for role in after.roles:
        if role.id in cargos_protegidos and role not in before.roles:
            try:
                await after.remove_roles(role, reason="Cargo protegido detectado")
                canal = discord.utils.get(after.guild.text_channels, name="logs")
                if canal:
                    await canal.send(f"{after.mention} tentou receber o cargo protegido {role.mention}, mas foi removido.")
            except:
                pass


# -----------------------------
# Setup
# -----------------------------
async def setup(bot: commands.Bot):
    bot.add_view(ProtecaoCargosView())

    @bot.event
    async def on_member_update(before, after):
        await verificar_alteracoes(bot, before, after)
