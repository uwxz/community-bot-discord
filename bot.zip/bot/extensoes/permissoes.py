import discord
from discord.ext import commands
import json
import os
import asyncio

PERMISSOES_FILE = "permissoes.json"
APARENCIA_FILE = "aparencia.json"

def carregar_permissoes():
    if not os.path.exists(PERMISSOES_FILE):
        with open(PERMISSOES_FILE, "w") as f:
            json.dump([], f)
    with open(PERMISSOES_FILE, "r") as f:
        return [int(i) for i in json.load(f)]

def salvar_permissoes(dados):
    with open(PERMISSOES_FILE, "w") as f:
        json.dump(dados, f, indent=4)

def cor_embed(guild_id):
    try:
        with open(APARENCIA_FILE, "r") as f:
            data = json.load(f)
        cor = data.get(str(guild_id), {}).get("cor", "#2f3136")
        return discord.Color.from_str(cor)
    except:
        return discord.Color.from_str("#2f3136")

class PermView(discord.ui.View):
    def __init__(self, ctx, permissoes):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.permissoes = permissoes

    @discord.ui.button(label="Adicionar", style=discord.ButtonStyle.success)
    async def adicionar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas quem usou o comando pode interagir.", ephemeral=True)

        await interaction.response.send_message("Mencione o usuário para **adicionar** permissão:", ephemeral=True)

        def check(m):
            return m.author == self.ctx.author and m.channel == self.ctx.channel and m.mentions

        try:
            msg = await self.ctx.bot.wait_for("message", timeout=30, check=check)
            membro = msg.mentions[0]
            await msg.delete()

            id_membro = int(membro.id)

            if id_membro not in self.permissoes:
                self.permissoes.append(id_membro)
                salvar_permissoes(self.permissoes)
                await self.ctx.send(f"{membro.mention} agora tem permissão para usar o bot.", delete_after=5)
            else:
                await self.ctx.send("Este usuário já possui permissão.", delete_after=5)

        except asyncio.TimeoutError:
            await self.ctx.send("Tempo esgotado.", delete_after=5)

    @discord.ui.button(label="Remover", style=discord.ButtonStyle.danger)
    async def remover(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas quem usou o comando pode interagir.", ephemeral=True)

        await interaction.response.send_message("Mencione o usuário para **remover** permissão:", ephemeral=True)

        def check(m):
            return m.author == self.ctx.author and m.channel == self.ctx.channel and m.mentions

        try:
            msg = await self.ctx.bot.wait_for("message", timeout=30, check=check)
            membro = msg.mentions[0]
            await msg.delete()

            id_membro = int(membro.id)

            if id_membro in self.permissoes:
                self.permissoes.remove(id_membro)
                salvar_permissoes(self.permissoes)
                await self.ctx.send(f"{membro.mention} teve a permissão removida.", delete_after=5)
            else:
                await self.ctx.send("Este usuário não possui permissão.", delete_after=5)

        except asyncio.TimeoutError:
            await self.ctx.send("Tempo esgotado.", delete_after=5)

    @discord.ui.button(label="Listar", style=discord.ButtonStyle.secondary)
    async def listar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas quem usou o comando pode interagir.", ephemeral=True)

        if not self.permissoes:
            texto = "Nenhum usuário com permissão."
        else:
            texto = "\n".join(f"<@{id}>" for id in self.permissoes)

        embed = discord.Embed(
            title="Usuários com Permissão",
            description=texto,
            color=cor_embed(self.ctx.guild.id)
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

class Permissoes(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def perm(self, ctx):
        await ctx.message.delete()

        permissoes = carregar_permissoes()
        if ctx.author.id != getattr(self.bot, "MEU_ID", None) and ctx.author.id not in permissoes:
            return await ctx.send("Você não tem permissão para usar esse comando.", delete_after=5)

        cor = cor_embed(ctx.guild.id)
        embed = discord.Embed(
            title="Permissões",
            description="Use os botões abaixo para adicionar ou remover permissões de usuarios.",
        )
        embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else self.bot.user.display_avatar.url)
        embed.set_footer(text=f"{ctx.author} • Hoje às {ctx.message.created_at.strftime('%H:%M')}")

        view = PermView(ctx, permissoes)
        await ctx.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(Permissoes(bot))
