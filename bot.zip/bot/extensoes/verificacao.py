import discord
from discord.ext import commands
import json
import os
from datetime import datetime

CONFIG_FILE = "verificacao.json"
APARENCIA_FILE = "aparencia.json"
CODIGOS_FILE = "codigos.json"


def carregar_config():
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def salvar_config(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def carregar_codigos():
    if not os.path.exists(CODIGOS_FILE):
        return []
    with open(CODIGOS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def cor_aparencia(guild_id: int):
    if os.path.exists(APARENCIA_FILE):
        with open(APARENCIA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            cor = data.get(str(guild_id), {}).get("cor")
            if cor:
                try:
                    return discord.Color.from_str(cor)
                except Exception:
                    pass
    return discord.Color.blurple()


async def abrir_painel_verificacao(ctx_or_interaction, bot):
    """
    Abre o painel. ctx_or_interaction pode ser commands.Context (comando prefix) ou discord.Interaction.
    """
    is_ctx = isinstance(ctx_or_interaction, commands.Context)
    user = ctx_or_interaction.author if is_ctx else ctx_or_interaction.user
    guild = ctx_or_interaction.guild

    embed = discord.Embed(
        title=f"{guild.name} | Painel de Verificação",
        description=(
            f"Olá {user.mention}, seja bem-vindo(a) ao **painel de verificação**!\n\n"
            "Logo abaixo estão os botões de configuração do sistema.\n\n"
            "**Obs:** O cargo do bot precisa estar **acima** do cargo de verificação/verificado."
        ),
        color=cor_aparencia(guild.id)
    )
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.set_footer(text=f"Configuração aberta por {user.display_name}")

    view = PainelVerificacao(ctx_or_interaction, bot)

    if is_ctx:
        await ctx_or_interaction.send(embed=embed, view=view)
    else:
        await ctx_or_interaction.response.send_message(embed=embed, view=view, ephemeral=True)


class PainelVerificacao(discord.ui.View):
    def __init__(self, ctx, bot):
        super().__init__(timeout=None)
        self.ctx = ctx
        self.bot = bot
        self.user = ctx.user if isinstance(ctx, discord.Interaction) else ctx.author

        config = carregar_config().get(str(self.ctx.guild.id), {})
        codigo_ativo = config.get("codigo_ativo", False)
        self.add_item(BotaoCodigo(codigo_ativo, self))

    async def esperar_mensagem(self, interaction, prompt):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem abriu o painel pode usar.", ephemeral=True)

        await interaction.response.send_message(prompt, ephemeral=True)

        def check(msg):
            return msg.author == self.user and msg.channel == interaction.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=60)
            try:
                await msg.delete()
            except Exception:
                pass
            return msg
        except Exception:
            aviso = await interaction.channel.send("Tempo esgotado.")
            await aviso.delete(delay=10)
            return None

    def atualizar_config(self, key, value):
        config = carregar_config()
        gid = str(self.ctx.guild.id)
        config[gid] = config.get(gid, {})
        config[gid][key] = value
        salvar_config(config)

    # ---------- BOTÕES DE CONFIG ----------
    @discord.ui.button(label="Cargo", style=discord.ButtonStyle.secondary)
    async def set_cargo(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Mencione o cargo de verificação:")
        if msg and msg.role_mentions:
            self.atualizar_config("cargo", msg.role_mentions[0].id)
            confirm = await interaction.channel.send(f"Cargo definido: {msg.role_mentions[0].mention}")
            await confirm.delete(delay=10)

    @discord.ui.button(label="Canal Fichas", style=discord.ButtonStyle.secondary)
    async def set_fichas(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Mencione o canal de fichas:")
        if msg and msg.channel_mentions:
            self.atualizar_config("fichas", msg.channel_mentions[0].id)
            confirm = await interaction.channel.send(f"Canal de fichas definido: {msg.channel_mentions[0].mention}")
            await confirm.delete(delay=10)

    @discord.ui.button(label="Canal Logs", style=discord.ButtonStyle.secondary)
    async def set_logs(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Mencione o canal de logs (ou envie o ID):")
        if msg:
            if msg.channel_mentions:
                canal_id = msg.channel_mentions[0].id
                guild_id = msg.guild.id
            elif msg.content.isdigit():
                canal_id = int(msg.content.strip())
                guild_id = self.ctx.guild.id
            else:
                return
            self.atualizar_config("logs", {"guild": guild_id, "canal": canal_id})
            confirm = await interaction.channel.send(f"Canal de logs definido: `{canal_id}`")
            await confirm.delete(delay=10)

    @discord.ui.button(label="Canal Publicação", style=discord.ButtonStyle.secondary)
    async def set_pub(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Mencione o canal de publicação:")
        if msg and msg.channel_mentions:
            self.atualizar_config("publicacao", msg.channel_mentions[0].id)
            confirm = await interaction.channel.send(f"Canal de publicação definido: {msg.channel_mentions[0].mention}")
            await confirm.delete(delay=10)

    @discord.ui.button(label="Título", style=discord.ButtonStyle.secondary)
    async def set_titulo(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Digite o título da embed:")
        if msg:
            self.atualizar_config("titulo", msg.content)
            confirm = await interaction.channel.send(f"Título definido: {msg.content}")
            await confirm.delete(delay=10)

    @discord.ui.button(label="Descrição", style=discord.ButtonStyle.secondary)
    async def set_desc(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Digite a descrição da embed:")
        if msg:
            self.atualizar_config("descricao", msg.content)
            confirm = await interaction.channel.send("Descrição definida.")
            await confirm.delete(delay=10)

    @discord.ui.button(label="Cor", style=discord.ButtonStyle.secondary)
    async def set_cor(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Digite a cor em HEX (ex: #5865F2):")
        if msg:
            self.atualizar_config("cor", msg.content)
            confirm = await interaction.channel.send(f"Cor definida: {msg.content}")
            await confirm.delete(delay=10)

    @discord.ui.button(label="Imagem", style=discord.ButtonStyle.secondary)
    async def set_imagem(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Envie a URL da imagem:")
        if msg:
            self.atualizar_config("imagem", msg.content)
            confirm = await interaction.channel.send("Imagem definida.")
            await confirm.delete(delay=10)

    @discord.ui.button(label="Thumbnail", style=discord.ButtonStyle.secondary)
    async def set_thumb(self, interaction, button):
        msg = await self.esperar_mensagem(interaction, "Envie a URL da thumbnail:")
        if msg:
            self.atualizar_config("thumbnail", msg.content)
            confirm = await interaction.channel.send("Thumbnail definida.")
            await confirm.delete(delay=10)

    # ---------- PRÉVIA E PUBLICAÇÃO ----------
    @discord.ui.button(label="Prévia", style=discord.ButtonStyle.primary)
    async def previa(self, interaction, button):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem abriu o painel pode usar.", ephemeral=True)

        config = carregar_config().get(str(self.ctx.guild.id), {})
        embed = discord.Embed(
            title=config.get("titulo", f"{self.ctx.guild.name} | Verificação"),
            description=config.get("descricao", "Clique no botão abaixo para iniciar."),
            color=discord.Color.from_str(config.get("cor")) if config.get("cor") else cor_aparencia(self.ctx.guild.id)
        )
        if config.get("thumbnail"):
            embed.set_thumbnail(url=config["thumbnail"])
        if config.get("imagem"):
            embed.set_image(url=config["imagem"])
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="Finalizar/Publicar", style=discord.ButtonStyle.success)
    async def finalizar(self, interaction, button):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem abriu o painel pode usar.", ephemeral=True)

        config = carregar_config().get(str(self.ctx.guild.id), {})
        canal_id = config.get("publicacao")
        if not canal_id:
            return await interaction.response.send_message("Nenhum canal de publicação configurado.", ephemeral=True)
        canal = interaction.client.get_channel(canal_id)
        if not canal:
            return await interaction.response.send_message("Canal inválido.", ephemeral=True)

        cor = discord.Color.from_str(config.get("cor")) if config.get("cor") else cor_aparencia(self.ctx.guild.id)
        embed = discord.Embed(
            title=config.get("titulo", f"{self.ctx.guild.name} | Verificação"),
            description=config.get("descricao", "Clique no botão abaixo para iniciar."),
            color=cor
        )
        if config.get("thumbnail"):
            embed.set_thumbnail(url=config["thumbnail"])
        if config.get("imagem"):
            embed.set_image(url=config["imagem"])

        view = IniciarVerificacaoView(self.ctx.guild.id, config.get("codigo_ativo", False))
        mensagem = await canal.send(embed=embed, view=view)

        # Salva a mensagem e canal para restaurar depois
        self.atualizar_config("mensagem_id", mensagem.id)
        self.atualizar_config("canal_pub_id", canal.id)

        await interaction.response.send_message("Verificação publicada!", ephemeral=True)

    @discord.ui.button(label="Resetar", style=discord.ButtonStyle.danger)
    async def resetar(self, interaction, button):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem abriu o painel pode usar.", ephemeral=True)

        config = carregar_config()
        config.pop(str(self.ctx.guild.id), None)
        salvar_config(config)
        await interaction.response.send_message("Configuração resetada.", ephemeral=True)


class BotaoCodigo(discord.ui.Button):
    def __init__(self, ativo: bool, painel):
        label = "Código Ativado" if ativo else "Código Desativado"
        style = discord.ButtonStyle.success if ativo else discord.ButtonStyle.danger
        super().__init__(label=label, style=style)
        self.ativo = ativo
        self.painel = painel

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.painel.user:
            return await interaction.response.send_message("Apenas quem abriu o painel pode usar.", ephemeral=True)

        novo_status = not self.ativo
        self.painel.atualizar_config("codigo_ativo", novo_status)

        embed = discord.Embed(
            title=f"{interaction.guild.name} | Painel de Verificação",
            description=(
                f"Olá {interaction.user.mention}, seja bem-vindo(a) ao **painel de verificação**!\n\n"
                "Logo abaixo estão os botões de configuração do sistema.\n\n"
                "**Obs:** O cargo do bot precisa estar **acima** do cargo de verificação/verificado."
            ),
            color=cor_aparencia(interaction.guild.id)
        )
        if interaction.guild.icon:
            embed.set_thumbnail(url=interaction.guild.icon.url)
        embed.set_footer(text=f"Configuração aberta por {interaction.user.display_name}")

        nova_view = PainelVerificacao(interaction, self.painel.bot)
        await interaction.response.edit_message(embed=embed, view=nova_view)


class IniciarVerificacaoView(discord.ui.View):
    def __init__(self, guild_id, codigo_ativo: bool):
        super().__init__(timeout=None)
        self.guild_id = guild_id
        self.codigo_ativo = codigo_ativo
        self.add_item(discord.ui.Button(label="Iniciar Verificação", style=discord.ButtonStyle.secondary, custom_id="verificacao:start"))
        if codigo_ativo:
            self.add_item(discord.ui.Button(label="Código", style=discord.ButtonStyle.secondary, custom_id="verificacao:codigo"))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        cid = None
        try:
            cid = interaction.data.get("custom_id")
        except Exception:
            pass
        if cid == "verificacao:start":
            await interaction.response.send_modal(VerificacaoModal(self.guild_id))
        elif cid == "verificacao:codigo":
            await interaction.response.send_modal(CodigoModal(self.guild_id))
        return True


class VerificacaoModal(discord.ui.Modal, title="Verificação"):
    def __init__(self, guild_id):
        super().__init__()
        self.guild_id = guild_id
        self.pergunta = discord.ui.TextInput(label="Quem você conhece no servidor?", style=discord.TextStyle.short, required=True, placeholder="Marque algum amigo")
        self.add_item(self.pergunta)

    async def on_submit(self, interaction: discord.Interaction):
        config = carregar_config().get(str(self.guild_id), {})
        fichas_id = config.get("fichas")
        if not fichas_id:
            return await interaction.response.send_message("Nenhum canal de fichas configurado.", ephemeral=True)

        canal_fichas = interaction.client.get_channel(fichas_id)
        cargo_id = config.get("cargo")

        embed = discord.Embed(title=f"Ficha de Verificação - {interaction.guild.name}", color=discord.Color.orange())
        embed.add_field(name="Usuário", value=f"{interaction.user.mention} / {interaction.user}", inline=False)
        embed.add_field(name="ID", value=str(interaction.user.id), inline=False)
        embed.add_field(name="Conta criada em", value=interaction.user.created_at.strftime('%d/%m/%Y %H:%M'), inline=False)
        embed.add_field(name="Pergunta", value=self.pergunta.label, inline=False)
        embed.add_field(name="Resposta", value=self.pergunta.value, inline=False)
        embed.set_thumbnail(url=interaction.user.display_avatar.url)

        logs_cfg = config.get("logs", {"guild": interaction.guild.id, "canal": None})
        view = AprovarOuRecusarView(interaction.user.id, cargo_id, logs_cfg)
        await canal_fichas.send(embed=embed, view=view)
        await interaction.response.send_message("Sua ficha foi enviada para análise da staff.", ephemeral=True)


class CodigoModal(discord.ui.Modal, title="Verificação com Código"):
    def __init__(self, guild_id):
        super().__init__()
        self.guild_id = guild_id
        self.codigo = discord.ui.TextInput(label="Digite seu código", style=discord.TextStyle.short, required=True, placeholder="Ex: ABC123")
        self.add_item(self.codigo)

    async def on_submit(self, interaction: discord.Interaction):
        config = carregar_config().get(str(self.guild_id), {})
        cargo_id = config.get("cargo")

        codigos = carregar_codigos()
        if self.codigo.value not in codigos:
            return await interaction.response.send_message("Código inválido.", ephemeral=True)

        member = interaction.guild.get_member(interaction.user.id)
        if not member:
            return await interaction.response.send_message("Usuário não encontrado.", ephemeral=True)

        if cargo_id:
            cargo = interaction.guild.get_role(cargo_id)
            if cargo:
                await member.add_roles(cargo, reason="Verificação com código")

        logs_cfg = config.get("logs", {"guild": interaction.guild.id, "canal": None})
        guild = interaction.client.get_guild(logs_cfg.get("guild", interaction.guild.id))
        if guild:
            canal = guild.get_channel(logs_cfg.get("canal"))
            if canal:
                embed = discord.Embed(title="Verificação com Código", color=discord.Color.blue(), timestamp=datetime.now())
                embed.add_field(name="Usuário", value=f"{member.mention} / {member}\n({member.id})", inline=False)
                embed.add_field(name="Código Usado", value=f"`{self.codigo.value}`", inline=False)
                embed.set_thumbnail(url=member.display_avatar.url)
                await canal.send(embed=embed)

        await interaction.response.send_message("Código válido! Você foi verificado.", ephemeral=True)


class AprovarOuRecusarView(discord.ui.View):
    def __init__(self, user_id, cargo_id, logs_config):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.cargo_id = cargo_id
        self.logs_config = logs_config

    async def enviar_log(self, interaction, member, aceito: bool):
        cor = discord.Color.green() if aceito else discord.Color.red()
        status = "Aceita" if aceito else "Recusada"
        staff_action = "Aceito por" if aceito else "Recusado por"

        embed = discord.Embed(title=f"Verificação {status}", color=cor, timestamp=datetime.now())
        embed.add_field(
            name="Usuário",
            value=f"{member.mention} / {member}\n({member.id})",
            inline=False
        )
        embed.add_field(
            name="Informações",
            value=f"{staff_action}: {interaction.user.mention} / {interaction.user}\n({interaction.user.id})",
            inline=False
        )
        embed.set_thumbnail(url=member.display_avatar.url)

        guild = interaction.client.get_guild(self.logs_config.get("guild", interaction.guild.id))
        if guild:
            canal = guild.get_channel(self.logs_config.get("canal"))
            if canal:
                await canal.send(embed=embed)

    # ---------- BOTÃO ACEITAR ----------
    @discord.ui.button(label="Aceitar", style=discord.ButtonStyle.success)
    async def aceitar(self, interaction: discord.Interaction, button: discord.ui.Button):
        member = interaction.guild.get_member(self.user_id)
        if not member:
            return await interaction.response.send_message("Usuário não encontrado.", ephemeral=True)

        cargo = interaction.guild.get_role(self.cargo_id)
        if cargo:
            await member.add_roles(cargo, reason="Ficha aprovada")

        await self.enviar_log(interaction, member, aceito=True)

        # Deleta a ficha após aprovação
        try:
            await interaction.message.delete()
        except Exception:
            pass

    # ---------- BOTÃO RECUSAR ----------
    @discord.ui.button(label="Recusar", style=discord.ButtonStyle.danger)
    async def recusar(self, interaction: discord.Interaction, button: discord.ui.Button):
        member = interaction.guild.get_member(self.user_id)
        if not member:
            return await interaction.response.send_message("Usuário não encontrado.", ephemeral=True)

        await self.enviar_log(interaction, member, aceito=False)

        # Deleta a ficha após recusa
        try:
            await interaction.message.delete()
        except Exception:
            pass


# -------------------------------------------------------
# SETUP DO COG / VIEW PERSISTENTE
# -------------------------------------------------------

async def setup(bot: commands.Bot):
    # Recarregar botões das mensagens antigas (views persistentes)
    config = carregar_config()
    for guild_id, cfg in config.items():
        canal_id = cfg.get("canal_pub_id")
        mensagem_id = cfg.get("mensagem_id")
        if canal_id and mensagem_id:
            canal = bot.get_channel(canal_id)
            if canal:
                try:
                    # Reanexa a view antiga aos botões já publicados
                    view = IniciarVerificacaoView(int(guild_id), cfg.get("codigo_ativo", False))
                    bot.add_view(view, message_id=mensagem_id)
                except Exception as e:
                    print(f"[ERRO] Não consegui restaurar view no servidor {guild_id}: {e}")

