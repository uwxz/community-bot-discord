import discord
from discord.ext import commands

class Expulsar(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="expulsar")
    @commands.has_permissions(kick_members=True)
    async def expulsar(self, ctx, role: discord.Role, *, motivo: str = None):
        """Expulsa todos os membros que têm o cargo mencionado: !expulsar @Cargo [motivo]"""
        if not ctx.guild.me.guild_permissions.kick_members:
            return await ctx.send("❌ Eu não tenho permissão de expulsar membros.")

        membros = role.members
        if not membros:
            return await ctx.send(f"Não há membros com o cargo {role.mention}.")

        motivo = motivo or f"Expulso por {ctx.author}."

        expulsos = 0
        falhas = 0
        falhas_lista = []

        for membro in membros:
            if not membro.guild_permissions.administrator and membro.top_role < ctx.author.top_role:
                try:
                    await membro.kick(reason=motivo)
                    expulsos += 1
                except Exception as e:
                    falhas += 1
                    falhas_lista.append(f"{membro} ({e})")
            else:
                falhas += 1
                falhas_lista.append(f"{membro} (não expulsável)")

        resposta = [
            f"✅ Expulsos: {expulsos}",
            f"❌ Falhas: {falhas}"
        ]
        if falhas_lista:
            resposta.append("Detalhes falhas: " + ", ".join(falhas_lista[:10]))

        await ctx.send("\n".join(resposta))

async def setup(bot):
    await bot.add_cog(Expulsar(bot))
