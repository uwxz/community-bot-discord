import discord
from discord.ext import commands
from discord.ui import Button, View
import asyncio
import json
import os

# Carrega a cor da embed a partir do arquivo aparencia.json na pasta raiz do bot
def carregar_cor_embed(guild_id: int):
    try:
        # Caminho para aparencia.json na pasta raiz (uma pasta acima da pasta 'extensoes')
        caminho_arquivo = os.path.join(os.path.dirname(os.path.dirname(__file__)), "aparencia.json")
        with open(caminho_arquivo, "r", encoding="utf-8") as f:
            dados = json.load(f)

        guild_id_str = str(guild_id)
        cor = dados.get(guild_id_str, {}).get("cor", "#5865F2")  # cor padrão caso não encontre
        return discord.Color.from_str(cor)
    except Exception as e:
        print(f"Erro ao carregar aparencia.json: {e}")
        return discord.Color.blurple()


# Modal para digitar a mensagem
class CriarMensagemModal(discord.ui.Modal, title="Criar Mensagem de Divulgação"):
    mensagem = discord.ui.TextInput(
        label="Mensagem para enviar por DM",
        style=discord.TextStyle.paragraph,
        placeholder="Digite a mensagem aqui...",
        required=True,
        max_length=2000
    )

    def __init__(self, mensagem_dict):
        super().__init__()
        self.mensagem_dict = mensagem_dict

    async def on_submit(self, interaction: discord.Interaction):
        self.mensagem_dict["content"] = self.mensagem.value
        await interaction.response.send_message("Mensagem criada com sucesso!", ephemeral=True)


class Divulgacao(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.mensagem_para_enviar = {"content": ""}
        self.log_message = None

    @commands.command()
    async def div(self, ctx):
        """Comando de divulgação com painel interativo"""

        cor = carregar_cor_embed(ctx.guild.id)
        guild_icon = ctx.guild.icon.url if ctx.guild.icon else None

        embed = discord.Embed(
            title=f"Painel de Divulgação - {ctx.guild.name}",
            description=(
                "Bem-vindo ao painel de divulgação do servidor!\n\n"
                "Aqui você pode **criar**, **enviar** e **resetar** uma mensagem personalizada que será enviada por DM "
                "para todos os membros do servidor (exceto bots).\n\n"
                "**Use os botões abaixo para gerenciar sua campanha de envio.**"
            ),
            color=cor
        )
        if guild_icon:
            embed.set_thumbnail(url=guild_icon)

        # Botões
        criar = Button(label="Criar", style=discord.ButtonStyle.green)
        enviar = Button(label="Enviar", style=discord.ButtonStyle.blurple)
        resetar = Button(label="Resetar", style=discord.ButtonStyle.red)

        # Callbacks
        async def criar_callback(interaction: discord.Interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Apenas o autor pode usar isso.", ephemeral=True)
            await interaction.response.send_modal(CriarMensagemModal(self.mensagem_para_enviar))

        async def enviar_callback(interaction: discord.Interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Apenas o autor pode usar isso.", ephemeral=True)

            if not self.mensagem_para_enviar["content"]:
                return await interaction.response.send_message("A mensagem está vazia. Use o botão 'Criar' antes de enviar.", ephemeral=True)

            await interaction.response.send_message("Iniciando envio de mensagens...", ephemeral=True)

            membros = [m for m in ctx.guild.members if not m.bot]
            total = len(membros)
            enviados = 0

            embed_log = discord.Embed(
                title="Enviando mensagens...",
                description=f"{enviados}/{total} enviados",
                color=cor
            )

            if self.log_message is None:
                self.log_message = await ctx.send(embed=embed_log)
            else:
                await self.log_message.edit(embed=embed_log)

            for membro in membros:
                try:
                    await membro.send(self.mensagem_para_enviar["content"])
                    enviados += 1
                except:
                    pass  # Ignora erros

                if enviados % 10 == 0 or enviados == total:
                    embed_log.description = f"{enviados}/{total} enviados"
                    await self.log_message.edit(embed=embed_log)
                    await asyncio.sleep(1)

            embed_log.title = "Envio concluído!"
            embed_log.color = discord.Color.green()
            await self.log_message.edit(embed=embed_log)

        async def resetar_callback(interaction: discord.Interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Apenas o autor pode usar isso.", ephemeral=True)
            self.mensagem_para_enviar["content"] = ""
            await interaction.response.send_message("Mensagem resetada com sucesso.", ephemeral=True)

        # View com os botões na ordem: Criar | Enviar | Resetar
        view = View()
        view.add_item(criar)
        view.add_item(enviar)
        view.add_item(resetar)

        criar.callback = criar_callback
        enviar.callback = enviar_callback
        resetar.callback = resetar_callback

        await ctx.send(embed=embed, view=view)


# Setup do cog
async def setup(bot):
    await bot.add_cog(Divulgacao(bot))
