import discord
from discord.ext import commands
import asyncio
import os

LAST_CHANNEL_FILE = "last_channel.txt"

class Connect(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        """Quando o cog é carregado, tenta reconectar no último canal"""
        if os.path.exists(LAST_CHANNEL_FILE):
            with open(LAST_CHANNEL_FILE, "r") as f:
                canal_id = f.read().strip()

            if canal_id.isdigit():
                canal = discord.utils.get(self.bot.get_all_channels(), id=int(canal_id))
                if isinstance(canal, discord.VoiceChannel):
                    try:
                        await canal.connect()
                        print(f" Reconectado automaticamente ao canal: {canal.name}")
                    except Exception as e:
                        print(f" Não consegui reconectar: {e}")

    @commands.command()
    async def connect(self, ctx, canal_id: int):
        canal = ctx.guild.get_channel(canal_id)

        if not isinstance(canal, discord.VoiceChannel):
            return await ctx.send("Esse ID não é de um canal de voz.", delete_after=5)

        try:
            await canal.connect()

            # salva o último canal em arquivo
            with open(LAST_CHANNEL_FILE, "w") as f:
                f.write(str(canal.id))

        except discord.ClientException:
            await ctx.send("Já estou conectado a um canal de voz.", delete_after=5)
        except Exception as e:
            await ctx.send(f"Erro ao conectar: {e}", delete_after=5)

        # tenta apagar a mensagem do comando
        try:
            await asyncio.sleep(0.2)
            await ctx.message.delete()
        except discord.Forbidden:
            await ctx.send(" Não tenho permissão para apagar mensagens.", delete_after=5)
        except Exception as e:
            await ctx.send(f" Erro ao apagar: {e}", delete_after=5)

async def setup(bot):
    await bot.add_cog(Connect(bot))
