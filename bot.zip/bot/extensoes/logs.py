import discord
from discord.ui import Button, View

class LogsView(View):
    def __init__(self):
        super().__init__(timeout=180)  # 3 minutos
        self.add_item(Button(label="Configuração Automática", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Logs Entrada", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Logs Saída", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Logs Call", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Logs Msg Delete", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Logs Msg Edit", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Logs Punições", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Logs Canais", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Logs Cargos", style=discord.ButtonStyle.secondary))
        self.add_item(Button(label="Desativar/Resetar ALL", style=discord.ButtonStyle.danger))

async def exibir_embed_logs(ctx):
    embed = discord.Embed(
        title=f"{ctx.guild.name} | Logs",
        description=(
            f"Olá {ctx.author.mention}, seja bem-vindo(a) ao painel de configurações de logs,\n"
            f"logo abaixo vai estar os botões de configuração do sistema.\n\n"
            "**Como funciona a configuração automática?**\n"
            "O bot vai criar uma categoria com o nome **Logs Boss™** e logo em\n"
            "seguida vai criar todos os canais de logs dentro da categoria que\n"
            "foi criada e no final de tudo o sistema de logs do seu servidor vai\n"
            "estar 100% configurado e funcionando!\n\n"
            "**Logs Entrada:**\nCanal: Nenhum\n"
            "**Logs Saída:**\nCanal: Nenhum\n"
            "**Logs Call:**\nCanal: Nenhum\n"
            "**Logs Mensagem Delete:**\nCanal: Nenhum\n"
            "**Logs Mensagem Edit:**\nCanal: Nenhum\n"
            "**Logs Punições:**\nCanal: Nenhum\n"
            "**Logs Canais:**\nCanal: Nenhum\n"
            "**Logs Cargos:**\nCanal: Nenhum\n\n"
            "*Você tem 3 minutos para finalizar tudo ou vai ser preciso usar o comando novamente!*"
        ),
        color=discord.Color.dark_gray()
    )

    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/URL_DA_IMAGEM")  # Substitua a URL

    await ctx.send(embed=embed, view=LogsView())
