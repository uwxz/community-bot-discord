import discord
from discord.ext import commands
import json
import os

PD_CONFIG_FILE = "pd_config.json"
COLEIRAS_FILE = "coleiras.json"

# -----------------------------
# Carregar / salvar arquivos
# -----------------------------
def carregar_config():
    if not os.path.exists(PD_CONFIG_FILE):
        with open(PD_CONFIG_FILE, "w") as f:
            json.dump({}, f)
    with open(PD_CONFIG_FILE, "r") as f:
        return json.load(f)


def salvar_config(config):
    with open(PD_CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)


def carregar_coleiras():
    if not os.path.exists(COLEIRAS_FILE):
        with open(COLEIRAS_FILE, "w") as f:
            json.dump({}, f)
    with open(COLEIRAS_FILE, "r") as f:
        return json.load(f)


def salvar_coleiras():
    with open(COLEIRAS_FILE, "w") as f:
        json.dump(coleiras, f, indent=4)


coleiras = carregar_coleiras()


def cor_embed(guild_id):
    try:
        with open("aparencia.json", "r") as f:
            data = json.load(f)
        cor = data.get(str(guild_id), {}).get("cor", "#2f3136")
        return discord.Color.from_str(cor)
    except:
        return discord.Color.from_str("#2f3136")


# -----------------------------
# Painel de configuração (Admin)
# -----------------------------
class ConfigPDView(discord.ui.View):
    def __init__(self, ctx, pd_config):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.pd_config = pd_config

    @discord.ui.button(label="Definir cargo de Dama", style=discord.ButtonStyle.gray)
    async def set_cargo(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas você pode usar.", ephemeral=True)

        await interaction.response.send_message("Mencione o cargo de Dama:", ephemeral=True)

        def check(msg):
            return msg.author == self.ctx.author and msg.channel == self.ctx.channel and msg.role_mentions

        try:
            msg = await self.ctx.bot.wait_for("message", timeout=30, check=check)
            role = msg.role_mentions[0]
            await msg.delete()
        except:
            return await self.ctx.send("Tempo esgotado ou inválido.", delete_after=5)

        gid = str(self.ctx.guild.id)
        self.pd_config.setdefault(gid, {})["cargo_dama"] = role.id
        salvar_config(self.pd_config)
        await self.ctx.send(f"Cargo de dama configurado: {role.mention}", delete_after=5)

    @discord.ui.button(label="Definir limite", style=discord.ButtonStyle.gray)
    async def set_limit(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas você pode usar.", ephemeral=True)

        await interaction.response.send_message("Mencione o cargo e o limite. Exemplo: `@VIP 3`", ephemeral=True)

        def check(msg):
            return msg.author == self.ctx.author and msg.channel == self.ctx.channel and msg.role_mentions

        try:
            msg = await self.ctx.bot.wait_for("message", timeout=30, check=check)
            role = msg.role_mentions[0]
            partes = msg.content.split()
            limite = int(partes[-1])
            await msg.delete()
        except:
            return await self.ctx.send("Tempo esgotado ou formato inválido.", delete_after=5)

        gid = str(self.ctx.guild.id)
        self.pd_config.setdefault(gid, {}).setdefault("limites", {})[str(role.id)] = limite
        salvar_config(self.pd_config)
        await self.ctx.send(f"Limite configurado: {limite} damas para {role.mention}", delete_after=5)


# -----------------------------
# View para usuários (!pd)
# -----------------------------
class PDUserView(discord.ui.View):
    def __init__(self, ctx, pd_config):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.pd_config = pd_config

    @discord.ui.button(label="Adicionar Dama", style=discord.ButtonStyle.green)
    async def add_dama(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas você pode usar.", ephemeral=True)

        await interaction.response.send_message("Mencione a pessoa que será sua Dama:", ephemeral=True)

        def check(msg):
            return msg.author == self.ctx.author and msg.channel == self.ctx.channel and msg.mentions

        try:
            msg = await self.ctx.bot.wait_for("message", timeout=30, check=check)
            dama = msg.mentions[0]
            await msg.delete()
        except:
            return await self.ctx.send("Tempo esgotado ou inválido.", delete_after=5)

        gid = str(self.ctx.guild.id)
        role_id = self.pd_config.get(gid, {}).get("cargo_dama")
        if not role_id:
            return await self.ctx.send("O cargo de Dama não está configurado.", delete_after=5)

        role = self.ctx.guild.get_role(role_id)
        if not role:
            return await self.ctx.send("O cargo configurado não existe mais.", delete_after=5)

        # Verificar limite
        limites = self.pd_config.get(gid, {}).get("limites", {})
        qtd_atual = sum(1 for m, dono in coleiras.items() if dono == self.ctx.author.id)
        max_damas = 0
        for rid, limite in limites.items():
            cargo_limite = self.ctx.guild.get_role(int(rid))
            if cargo_limite and cargo_limite in self.ctx.author.roles:
                max_damas = max(max_damas, limite)

        if max_damas and qtd_atual >= max_damas:
            return await self.ctx.send(f"Você já atingiu o limite de {max_damas} damas.", delete_after=5)

        try:
            await dama.add_roles(role)
        except:
            return await self.ctx.send("Não consegui atribuir o cargo à pessoa.", delete_after=5)

        coleiras[str(dama.id)] = self.ctx.author.id
        salvar_coleiras()

        await self.ctx.send(f"{dama.mention} agora é sua Dama!", delete_after=5)

    @discord.ui.button(label="Remover Dama", style=discord.ButtonStyle.red)
    async def remove_dama(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Apenas você pode usar.", ephemeral=True)

        await interaction.response.send_message("Mencione a pessoa que deseja remover das suas Damas:", ephemeral=True)

        def check(msg):
            return msg.author == self.ctx.author and msg.channel == self.ctx.channel and msg.mentions

        try:
            msg = await self.ctx.bot.wait_for("message", timeout=30, check=check)
            dama = msg.mentions[0]
            await msg.delete()
        except:
            return await self.ctx.send("Tempo esgotado ou inválido.", delete_after=5)

        gid = str(self.ctx.guild.id)
        role_id = self.pd_config.get(gid, {}).get("cargo_dama")
        if not role_id:
            return await self.ctx.send("O cargo de Dama não está configurado.", delete_after=5)

        role = self.ctx.guild.get_role(role_id)
        if not role:
            return await self.ctx.send("O cargo configurado não existe mais.", delete_after=5)

        if coleiras.get(str(dama.id)) != self.ctx.author.id:
            return await self.ctx.send("Essa pessoa não é sua Dama.", delete_after=5)

        try:
            await dama.remove_roles(role)
        except:
            return await self.ctx.send("Não consegui remover o cargo da pessoa.", delete_after=5)

        del coleiras[str(dama.id)]
        salvar_coleiras()

        await self.ctx.send(f"{dama.mention} não é mais sua Dama.", delete_after=5)


# -----------------------------
# Cog principal
# -----------------------------
class PrimeiraDama(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.pd_config = carregar_config()

    async def abrir_painel_dama(self, ctx, interaction=None):
        """Painel de configuração (apenas admin)"""
        gid = str(ctx.guild.id)
        cargo_id = self.pd_config.get(gid, {}).get("cargo_dama")

        cargo_txt = f"<@&{cargo_id}>" if cargo_id else "Nenhum configurado"
        limites = self.pd_config.get(gid, {}).get("limites", {})
        limites_txt = "\n".join([f"<@&{rid}> ➝ {qtd}" for rid, qtd in limites.items()]) if limites else "Nenhum limite definido."

        embed = discord.Embed(
            title="Configuração Primeira Dama",
            description="Use os botões abaixo para configurar.",
            color=cor_embed(ctx.guild.id)
        )
        embed.add_field(name="Cargo de Dama", value=cargo_txt, inline=False)
        embed.add_field(name="Limites", value=limites_txt, inline=False)
        embed.set_footer(text="Sistema de Primeira Dama", icon_url=ctx.guild.icon.url if ctx.guild.icon else None)

        view = ConfigPDView(ctx, self.pd_config)

        if interaction:
            await interaction.message.edit(embed=embed, view=view)
        else:
            await ctx.send(embed=embed, view=view)

    @commands.command(name="pd")
    async def primeira_dama(self, ctx):
        """Mostra painel do usuário com suas damas"""
        role_id = self.pd_config.get(str(ctx.guild.id), {}).get("cargo_dama")
        if not role_id:
            return await ctx.send(" O sistema de Primeira Dama ainda não está configurado.")

        role = ctx.guild.get_role(role_id)
        if not role:
            return await ctx.send(" O cargo configurado não foi encontrado.")

        damas = [
            m for m in ctx.guild.members
            if role in m.roles and coleiras.get(str(m.id)) == ctx.author.id
        ]
        descricao = "\n".join([m.name for m in damas]) if damas else "Nenhuma dama!"

        embed = discord.Embed(
            title=f"Damas de {ctx.author.name}",
            description="**Suas Damas:**\n" + descricao,
            color=cor_embed(ctx.guild.id)
        )
        embed.set_thumbnail(url=ctx.author.display_avatar.url)
        embed.set_footer(text="Sistema de Primeira Dama", icon_url=ctx.guild.icon.url if ctx.guild.icon else None)

        view = PDUserView(ctx, self.pd_config)
        await ctx.send(embed=embed, view=view)


# -----------------------------
# Setup
# -----------------------------
async def setup(bot):
    await bot.add_cog(PrimeiraDama(bot))
