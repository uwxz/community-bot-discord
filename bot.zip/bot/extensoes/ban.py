import discord
from discord.ext import commands
import json
import os

# Arquivo para salvar os contadores
BAN_COUNT_FILE = "ban_count.json"
APARENCIA_FILE = "aparencia.json"


def load_data():
    if not os.path.exists(BAN_COUNT_FILE):
        return {}
    with open(BAN_COUNT_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_data(data):
    with open(BAN_COUNT_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


def load_aparencia():
    if not os.path.exists(APARENCIA_FILE):
        return {}
    with open(APARENCIA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


class Ban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ban(self, ctx, membro: discord.Member = None, *, motivo: str = None):
        await ctx.message.delete()

        if not ctx.author.guild_permissions.ban_members:
            return

        if membro is None:
            return

        motivo = motivo or "Nenhum motivo inserido."

        try:
            await ctx.guild.ban(membro, reason=motivo, delete_message_days=0)
        except Exception as e:
            print(f"[ERRO BAN] {e}")
            return

        data = load_data()
        aparencia = load_aparencia()

        staff_id = str(ctx.author.id)
        data[staff_id] = data.get(staff_id, 0) + 1
        save_data(data)

        cor = discord.Color.from_str(
            aparencia.get(str(ctx.guild.id), {}).get("cor", "#2f3136")
        )

        log_embed = discord.Embed(
            description=f"# {ctx.guild.name} | Banimento",
            color=cor
        )
        log_embed.add_field(
            name="Autor do Banimento:",
            value=f"{ctx.author.mention} | `{ctx.author.id}`",
            inline=False
        )
        log_embed.add_field(
            name="Membro Banido:",
            value=f"{membro.mention} | `{membro.id}`",
            inline=False
        )
        log_embed.add_field(
            name="Motivo:",
            value=f"```{motivo}```",
            inline=False
        )
        if hasattr(membro, "display_avatar"):
            log_embed.set_thumbnail(url=membro.display_avatar.url)
        log_embed.set_footer(
            text=f"{ctx.author.display_name} já baniu {data[staff_id]} usuários. | Limite de ban 1/25"
        )

        log_channel = discord.utils.get(ctx.guild.text_channels, name="logs")
        if log_channel:
            await log_channel.send(embed=log_embed, delete_after=10)
        else:
            await ctx.send(embed=log_embed, delete_after=10)

    @commands.command()
    async def unban(self, ctx, user: str = None, *, motivo: str = None):
        await ctx.message.delete()

        if not ctx.author.guild_permissions.ban_members:
            return

        if user is None:
            return

        try:
            user_id = int(user.replace("<@", "").replace(">", "").replace("!", ""))
            membro = await self.bot.fetch_user(user_id)
        except:
            return

        motivo = motivo or "Nenhum motivo inserido."

        try:
            await ctx.guild.unban(membro, reason=motivo)
        except Exception as e:
            print(f"[ERRO UNBAN] {e}")
            return

        aparencia = load_aparencia()

        cor = discord.Color.from_str(
            aparencia.get(str(ctx.guild.id), {}).get("cor", "#2f3136")
        )

        log_embed = discord.Embed(
            description=f"# {ctx.guild.name} | Desbanimento",
            color=cor
        )
        log_embed.add_field(
            name="Autor do Desbanimento:",
            value=f"{ctx.author.mention} | `{ctx.author.id}`",
            inline=False
        )
        log_embed.add_field(
            name="Usuário Desbanido:",
            value=f"{membro.mention if hasattr(membro, 'mention') else membro.name} | `{membro.id}`",
            inline=False
        )
        log_embed.add_field(
            name="Motivo:",
            value=f"```{motivo}```",
            inline=False
        )
        if hasattr(membro, "display_avatar"):
            log_embed.set_thumbnail(url=membro.display_avatar.url)
        log_embed.set_footer(text=f"{ctx.author.display_name} realizou um desbanimento.")

        log_channel = discord.utils.get(ctx.guild.text_channels, name="logs")
        if log_channel:
            await log_channel.send(embed=log_embed, delete_after=10)
        else:
            await ctx.send(embed=log_embed, delete_after=10)


async def setup(bot):
    await bot.add_cog(Ban(bot))
