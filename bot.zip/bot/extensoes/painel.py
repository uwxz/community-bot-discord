import discord
from discord.ext import commands
import json
import os
from datetime import datetime

from extensoes.financeiro import exibir_embed_financeiro
from extensoes.aparencia import exibir_embed_aparencia
from extensoes.antibot import exibir_embed_antibot
from extensoes.logs import exibir_embed_logs
from extensoes.blacklist import exibir_embed_blacklist_config
from extensoes.insta import exibir_embed_insta_config
from extensoes.protecaocargos import exibir_embed_protecao_cargos
from extensoes.backup import exibir_embed_backup  # ✅ import Backup

MESES_PT = {
    "January": "Janeiro", "February": "Fevereiro", "March": "Março",
    "April": "Abril", "May": "Maio", "June": "Junho",
    "July": "Julho", "August": "Agosto", "September": "Setembro",
    "October": "Outubro", "November": "Novembro", "December": "Dezembro"
}

def formatar_data_brasileira(data_str):
    try:
        dt = datetime.strptime(data_str, "%Y-%m-%d")
        mes_pt = MESES_PT[dt.strftime("%B")]
        return f"{dt.day:02d} de {mes_pt} de {dt.year}"
    except:
        return "Data inválida"

# Função para enviar painel principal
async def enviar_embed_painel_principal(ctx, bot, interaction=None):
    data_exp = "Sem data configurada."
    if os.path.exists("dias.json"):
        with open("dias.json", "r") as f:
            data = json.load(f)
        if "expira" in data:
            data_exp = formatar_data_brasileira(data["expira"])

    cor = "#2f3136"
    if os.path.exists("aparencia.json"):
        with open("aparencia.json", "r") as f:
            cores = json.load(f)
        cor = cores.get(str(ctx.guild.id), {}).get("cor", cor)

    embed = discord.Embed(
        title="Painel de Configurações",
        description="Escolha abaixo a categoria que deseja configurar:",
        color=discord.Color.from_str(cor)
    )

    embed.add_field(name="Administrador(a)", value=f"{ctx.author.mention}\n(`{ctx.author.name}`)", inline=True)
    embed.add_field(name="Expira em", value=data_exp, inline=True)
    embed.add_field(
        name="Links úteis",
        value="**[Comandos](https://discord.com)** | **[Suporte](https://discord.com)** | **[Meu Site](https://discord.com)**",
        inline=False
    )
    embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else ctx.bot.user.display_avatar.url)
    embed.set_footer(
        text=f"Solicitado por {ctx.author.display_name} • Hoje às {datetime.now().strftime('%H:%M')}",
        icon_url=ctx.author.display_avatar.url
    )

    view = PainelSelect(bot, ctx)
    if interaction:
        await interaction.message.edit(embed=embed, view=view)
    else:
        await ctx.send(embed=embed, view=view)

# -------------------------
# VIEWS DE SELEÇÃO
# -------------------------
class PainelSelect(discord.ui.View):
    def __init__(self, bot, ctx_or_interaction):
        super().__init__(timeout=60)
        self.bot = bot
        self.ctx = ctx_or_interaction
        self.user = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author

    @discord.ui.select(
        placeholder="Nada selecionado",
        options=[
            discord.SelectOption(label="Financeiro", description="Renove o bot por aqui"),
            discord.SelectOption(label="Aparência", description="Configurações visuais do bot"),
            discord.SelectOption(label="Segurança", description="Sistemas de proteção do bot"),
            discord.SelectOption(label="Servidor", description="Configurações específicas do servidor"),
            discord.SelectOption(label="Comunidade", description="Configurações da comunidade"),
            discord.SelectOption(label="Primeira dama", description="Configurar sistema de Primeira Dama"),
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem executou o painel pode usar.", ephemeral=True)

        escolha = select.values[0]

        if escolha == "Financeiro":
            await interaction.response.defer()
            await exibir_embed_financeiro(self.ctx)
            await interaction.message.edit(view=PainelSelect(self.bot, self.ctx))

        elif escolha == "Aparência":
            await interaction.response.defer()
            await exibir_embed_aparencia(self.ctx)
            await interaction.message.edit(view=PainelSelect(self.bot, self.ctx))

        elif escolha == "Segurança":
            await interaction.response.defer()
            await interaction.message.edit(view=SelectSegurancaMenu(self.ctx, self.bot))

        elif escolha == "Servidor":
            await interaction.response.defer()
            await interaction.message.edit(view=SelectServidorMenu(self.ctx))

        elif escolha == "Comunidade":
            await interaction.response.defer()
            await interaction.message.edit(view=SelectComunidadeMenu(self.ctx, self.bot))

        elif escolha == "Primeira dama":
            await interaction.response.defer()
            cog = self.bot.get_cog("PrimeiraDama")
            if cog:
                await cog.abrir_painel_dama(self.ctx, interaction=interaction)
            else:
                await interaction.followup.send("Cog Primeira Dama não carregada.", ephemeral=True)

# -------------------------
# MENU DE SEGURANÇA
# -------------------------
class SelectSegurancaMenu(discord.ui.View):
    def __init__(self, ctx_or_interaction, bot):
        super().__init__(timeout=60)
        self.ctx = ctx_or_interaction
        self.bot = bot
        self.user = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author

    @discord.ui.select(
        placeholder="Nada selecionado",
        options=[
            discord.SelectOption(label="Antibot", description="Gerencie o sistema AntiBot"),
            discord.SelectOption(label="Logs", description="Configurações de logs do servidor"),
            discord.SelectOption(label="Blacklist", description="Gerenciar blacklist do servidor"),
            discord.SelectOption(label="Proteção de Cargos", description="Gerenciar cargos protegidos"),
            discord.SelectOption(label="Backup", description="Gerenciar sistema de backup"),  # ✅ Backup
            discord.SelectOption(label="Voltar", description="Retornar ao painel principal")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem executou este painel pode usar.", ephemeral=True)

        escolha = select.values[0]

        if escolha == "Antibot":
            await interaction.response.defer()
            await exibir_embed_antibot(self.ctx)

        elif escolha == "Logs":
            await exibir_embed_logs(interaction)

        elif escolha == "Blacklist":
            await exibir_embed_blacklist_config(interaction, self.bot)

        elif escolha == "Proteção de Cargos":
            await exibir_embed_protecao_cargos(interaction, self.bot)

        elif escolha == "Backup":
            await exibir_embed_backup(interaction, self.bot)  # ✅ chama a embed de backup

        elif escolha == "Voltar":
            await interaction.response.defer()
            await enviar_embed_painel_principal(self.ctx, interaction=interaction, bot=self.bot)

# -------------------------
# MENUS SERVIDOR E COMUNIDADE (mantidos iguais)
# -------------------------
class SelectServidorMenu(discord.ui.View):
    def __init__(self, ctx_or_interaction):
        super().__init__(timeout=60)
        self.ctx = ctx_or_interaction
        self.user = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author

    @discord.ui.select(
        placeholder="Nada selecionado",
        options=[
            discord.SelectOption(label="CL", description="Configurar palavra CL para apagar mensagens"),
            discord.SelectOption(label="Contador", description="Canal que mostra pessoas em call"),
            discord.SelectOption(label="Verificação", description="Sistema de verificação de membros"),
            discord.SelectOption(label="Voltar", description="Retornar ao painel principal")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem executou este painel pode usar.", ephemeral=True)

        escolha = select.values[0]

        if escolha == "CL":
            await interaction.response.defer()
            cog = interaction.client.get_cog("CL")
            if cog:
                await cog.exibir_embed_cl(interaction)

        elif escolha == "Contador":
            await interaction.response.defer()
            from extensoes.contador import exibir_embed_contador
            await exibir_embed_contador(interaction)

        elif escolha == "Verificação":
            try:
                from extensoes.verificacao import abrir_painel_verificacao
                await abrir_painel_verificacao(interaction, interaction.client)
            except Exception as e:
                await interaction.followup.send(f"Erro ao abrir painel de verificação: {e}", ephemeral=True)

        elif escolha == "Voltar":
            await interaction.response.defer()
            await enviar_embed_painel_principal(self.ctx, interaction=interaction, bot=interaction.client)

class SelectComunidadeMenu(discord.ui.View):
    def __init__(self, ctx_or_interaction, bot):
        super().__init__(timeout=60)
        self.ctx = ctx_or_interaction
        self.bot = bot
        self.user = ctx_or_interaction.user if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction.author

    @discord.ui.select(
        placeholder="Nada selecionado",
        options=[
            discord.SelectOption(label="Instagram", description="Abrir painel de configuração do Insta"),
            discord.SelectOption(label="Voltar", description="Retornar ao painel principal")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem executou este painel pode usar.", ephemeral=True)

        escolha = select.values[0]

        if escolha == "Instagram":
            await interaction.response.defer(ephemeral=True)
            await exibir_embed_insta_config(interaction, self.bot)

        elif escolha == "Voltar":
            await interaction.response.defer()
            await enviar_embed_painel_principal(self.ctx, interaction=interaction, bot=self.bot)

# -------------------------
# COG PRINCIPAL
# -------------------------
class Painel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def painel(self, ctx):
        if not hasattr(self.bot, "permissoes"):
            self.bot.permissoes = set()

        if ctx.author.id not in self.bot.permissoes and ctx.author.id != getattr(self.bot, "MEU_ID", None):
            return await ctx.send("Você não tem permissão para usar este comando.")

        await enviar_embed_painel_principal(ctx, self.bot)

async def setup(bot):
    await bot.add_cog(Painel(bot))
