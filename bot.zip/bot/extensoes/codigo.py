import discord
from discord.ext import commands
import json
import os

CONFIG_FILE = "codigos.json"
APARENCIA_FILE = "aparencia.json"


# ========== Funções utilitárias ==========
def carregar_codigos():
    if not os.path.exists(CONFIG_FILE):
        return []
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
            if isinstance(data, list):
                return data
            return []  # força ser lista
        except:
            return []


def salvar_codigos(codigos):
    if not isinstance(codigos, list):
        codigos = []
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(codigos, f, indent=4, ensure_ascii=False)


def cor_aparencia(guild_id: int):
    if os.path.exists(APARENCIA_FILE):
        with open(APARENCIA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            cor = data.get(str(guild_id), {}).get("cor")
            if cor:
                return discord.Color.from_str(cor)
    return discord.Color.blurple()


# ========== View com botões ==========
class CodigoView(discord.ui.View):
    def __init__(self, bot, user, guild_id):
        super().__init__(timeout=None)
        self.bot = bot
        self.user = user
        self.guild_id = guild_id

    async def esperar_msg(self, interaction, prompt):
        if interaction.user != self.user:
            return await interaction.response.send_message("Apenas quem abriu o painel pode usar.", ephemeral=True)

        await interaction.response.send_message(prompt, ephemeral=True)

        def check(msg):
            return msg.author == self.user and msg.channel == interaction.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=30)
            conteudo = msg.content.strip()
            await msg.delete()
            return conteudo
        except:
            await interaction.channel.send("Tempo esgotado.", delete_after=10)
            return None

    # ------- Botão Criar -------
    @discord.ui.button(label="Criar", style=discord.ButtonStyle.success)
    async def criar(self, interaction: discord.Interaction, button: discord.ui.Button):
        codigo = await self.esperar_msg(interaction, "Digite o código para criar:")
        if not codigo:
            return
        if not codigo.isalnum():
            return await interaction.channel.send("O código só pode conter letras e números.", delete_after=10)

        codigos = carregar_codigos()
        if codigo in codigos:
            return await interaction.channel.send(f"O código `{codigo}` já existe.", delete_after=10)

        codigos.append(codigo)
        salvar_codigos(codigos)
        await interaction.channel.send(f"Código `{codigo}` adicionado com sucesso!", delete_after=10)

    # ------- Botão Apagar -------
    @discord.ui.button(label="Apagar", style=discord.ButtonStyle.danger)
    async def apagar(self, interaction: discord.Interaction, button: discord.ui.Button):
        codigo = await self.esperar_msg(interaction, "Digite o código para apagar:")
        if not codigo:
            return

        codigos = carregar_codigos()
        if codigo not in codigos:
            return await interaction.channel.send(f"O código `{codigo}` não existe.", delete_after=10)

        codigos.remove(codigo)
        salvar_codigos(codigos)
        await interaction.channel.send(f"Código `{codigo}` removido com sucesso!", delete_after=10)

    # ------- Botão Listar -------
    @discord.ui.button(label="Listar", style=discord.ButtonStyle.secondary)
    async def listar(self, interaction: discord.Interaction, button: discord.ui.Button):
        codigos = carregar_codigos()
        if not codigos:
            texto = "Nenhum código cadastrado."
        else:
            texto = "\n".join([f"- {c}" for c in codigos])

        embed = discord.Embed(
            title="Lista de Códigos",
            description=texto,
            color=cor_aparencia(self.guild_id)
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


# ========== Comando ==========
class CodigoCMD(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="codigo")
    async def codigo(self, ctx: commands.Context):
        embed = discord.Embed(
            title="Gerenciamento de Códigos",
            description=(
                "**Instruções:**\n"
                "• Use os botões abaixo para criar, apagar ou listar códigos de verificação.\n"
                "• Os códigos só podem conter letras e números."
            ),
            color=cor_aparencia(ctx.guild.id)
        )
        embed.set_footer(text=f"Solicitado por {ctx.author.display_name}")

        view = CodigoView(self.bot, ctx.author, ctx.guild.id)
        await ctx.send(embed=embed, view=view)


# ========== Setup ==========
async def setup(bot):
    await bot.add_cog(CodigoCMD(bot))
