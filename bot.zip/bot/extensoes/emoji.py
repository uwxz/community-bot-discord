import discord
from discord.ext import commands
import aiohttp
import re

class Emoji(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="addemoji")  # agora é !addemoji
    @commands.has_permissions(manage_emojis=True)
    async def addemoji(self, ctx, *, emojis: str):
        """Adiciona emojis de outros servidores de uma vez"""
        custom_emojis = re.findall(r"<(a?):(\w+):(\d+)>", emojis)

        if not custom_emojis:
            return await ctx.send(" Nenhum emoji válido encontrado na mensagem!")

        added = []
        failed = []

        async with aiohttp.ClientSession() as session:
            for animated, name, emoji_id in custom_emojis:
                url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{'gif' if animated else 'png'}"

                async with session.get(url) as resp:
                    if resp.status != 200:
                        failed.append(name)
                        continue

                    try:
                        img = await resp.read()
                        emoji = await ctx.guild.create_custom_emoji(name=name, image=img)
                        added.append(f"<:{emoji.name}:{emoji.id}>")
                    except Exception:
                        failed.append(name)

        msg = ""
        if added:
            msg += f" Adicionados: {' '.join(added)}\n"
        if failed:
            msg += f" Falharam: {', '.join(failed)}"

        await ctx.send(msg)

async def setup(bot):
    await bot.add_cog(Emoji(bot))
