import discord
from discord.ext import commands, tasks
import json
import os

ARQUIVO = "contador.json"
APARENCIA = "aparencia.json"

def carregar_config():
    if not os.path.exists(ARQUIVO):
        with open(ARQUIVO, "w") as f:
            json.dump({}, f)
    with open(ARQUIVO, "r") as f:
        return json.load(f)

def salvar_config(data):
    with open(ARQUIVO, "w") as f:
        json.dump(data, f, indent=4)

def cor_embed(guild_id):
    try:
        with open(APARENCIA, "r") as f:
            data = json.load(f)
            cor = data.get(str(guild_id), {}).get("cor", "#2f3136")
            return discord.Color.from_str(cor)
    except:
        return discord.Color.dark_gray()

class Contador(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = carregar_config()
        self.atualizar_contador.start()

    @tasks.loop(seconds=30)  # Atualiza a cada 10 minutos
    async def atualizar_contador(self):
        for guild_id, dados in self.config.items():
            guild = self.bot.get_guild(int(guild_id))
            if not guild:
                continue

            canal_configurado = guild.get_channel(dados.get("canal_id"))
            if not isinstance(canal_configurado, (discord.VoiceChannel, discord.CategoryChannel)):
                continue

            total = sum(len(vc.members) for vc in guild.voice_channels)
            nome_base = dados.get("nome", "Contador")
            novo_nome = f"{nome_base}: {total}"
            nome_anterior = dados.get("ultimo_nome", "")

            if novo_nome != nome_anterior:
                try:
                    await canal_configurado.edit(name=novo_nome)
                    self.config[guild_id]["ultimo_nome"] = novo_nome
                    salvar_config(self.config)
                except Exception as e:
                    print(f"Erro ao atualizar nome do canal no guild {guild_id}: {e}")

    @atualizar_contador.before_loop
    async def before_loop(self):
        await self.bot.wait_until_ready()

config = carregar_config()

async def exibir_embed_contador(interaction: discord.Interaction):
    guild = interaction.guild
    user = interaction.user
    guild_id = str(guild.id)
    dados = config.get(guild_id, {})
    canal_id = dados.get("canal_id")
    canal = guild.get_channel(canal_id) if canal_id else None
    nome_base = dados.get("nome", "Contador")
    texto_canal = f"<#{canal.id}>" if canal else "Nenhum canal configurado"

    embed = discord.Embed(
        title="Canal de contador de call do servidor",
        description=(
            f"Configure um canal de voz ou categoria para exibir a quantidade de membros em call.\n\n"
            f"**Canal:** {texto_canal}"
        ),
        color=cor_embed(guild.id)
    )
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)

    class Painel(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=None)

        @discord.ui.button(label="Canal", style=discord.ButtonStyle.blurple)
        async def canal(self, button_interaction: discord.Interaction, button: discord.ui.Button):
            if button_interaction.user != user:
                return await button_interaction.response.send_message(
                    "Apenas quem abriu o painel pode configurar.", ephemeral=True
                )

            class ModalContador(discord.ui.Modal, title="Configurar Contador"):
                canal_id = discord.ui.TextInput(
                    label="ID do canal de voz ou categoria", placeholder="1234567890", required=True
                )
                nome_base = discord.ui.TextInput(
                    label="Nome base do canal", placeholder="Pessoas em call", required=True
                )

                async def on_submit(modal_self, interaction: discord.Interaction):
                    try:
                        canal_id_int = int(modal_self.canal_id.value)
                        nome_base_str = modal_self.nome_base.value
                        canal_conf = guild.get_channel(canal_id_int)

                        if not isinstance(canal_conf, (discord.VoiceChannel, discord.CategoryChannel)):
                            return await interaction.response.send_message(
                                "ID inválido ou não é um canal/categoria.", ephemeral=True
                            )

                        config[guild_id] = {
                            "canal_id": canal_id_int,
                            "nome": nome_base_str,
                            "ultimo_nome": ""
                        }
                        salvar_config(config)

                        novo_embed = discord.Embed(
                            title="Canal de contador de call do servidor",
                            description=(
                                f"Configure um canal de voz ou categoria para exibir a quantidade de membros em call.\n\n"
                                f"**Canal:** <#{canal_id_int}>"
                            ),
                            color=cor_embed(guild.id)
                        )
                        if guild.icon:
                            novo_embed.set_thumbnail(url=guild.icon.url)

                        await interaction.message.edit(embed=novo_embed, view=Painel())
                        await interaction.response.send_message("Contador configurado com sucesso!", ephemeral=True)

                    except Exception as e:
                        await interaction.response.send_message(f"Erro: {e}", ephemeral=True)

            await button_interaction.response.send_modal(ModalContador())

        @discord.ui.button(label="Voltar", style=discord.ButtonStyle.red)
        async def voltar(self, button_interaction: discord.Interaction, button: discord.ui.Button):
            if button_interaction.user != user:
                return await button_interaction.response.send_message(
                    "Apenas quem abriu o painel pode usar esse botão.", ephemeral=True
                )

            # IMPORTANTE: aqui você precisa importar PainelSelect de seu painel.py
            # Se não quiser importar aqui, passe uma função ou view como parâmetro, ou ajuste a estrutura do seu projeto.
            from extensoes.painel import PainelSelect
            await button_interaction.message.edit(embed=None, view=PainelSelect(interaction))

    await interaction.message.edit(embed=embed, view=Painel())


async def setup(bot):
    await bot.add_cog(Contador(bot))


__all__ = ["Contador", "exibir_embed_contador"]
