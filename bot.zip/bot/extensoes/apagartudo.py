# extensoes/apagartudo.py
import discord
from discord.ext import commands
import asyncio
from typing import Optional

class ApagarTudo(commands.Cog):
    """Cog com comando c!apagartudo — deleta canais e cargos do servidor (com checagens)."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def is_guild_owner_check(self):
        async def predicate(ctx: commands.Context) -> bool:
            return ctx.guild is not None and ctx.author == ctx.guild.owner
        return commands.check(predicate)

    @commands.command(name="apagartudo")
    @commands.guild_only()
    @commands.check_any(commands.is_owner(), commands.has_permissions(administrator=True), commands.check(lambda ctx: ctx.guild and ctx.author == ctx.guild.owner))
    async def apagartudo(self, ctx: commands.Context):
        """
        c!apagartudo
        Deleta todos os canais e cargos do servidor (respeita hierarquia do bot).
        Protegido por: dono do bot OR dono do servidor OR administradores.
        """
        guild: Optional[discord.Guild] = ctx.guild
        if guild is None:
            return await ctx.send(" Este comando só pode ser usado em servidores.")

        # Confirmação textual (mais seguro que um simples reaction)
        warning = (
            "** AVISO — COMANDO DESTRUÍDO **\n\n"
            "Isto irá tentar **deletar todos os canais** e **todos os cargos** do servidor.\n"
            "Isto é **irreversível**. Se você tem certeza, digite `confirmar` neste canal dentro de 25 segundos.\n"
            "Para cancelar, digite qualquer outra coisa ou espere o tempo expirar."
        )
        await ctx.send(warning)

        def check_msg(m: discord.Message) -> bool:
            return m.author == ctx.author and m.channel == ctx.channel

        try:
            msg = await self.bot.wait_for("message", timeout=25.0, check=check_msg)
        except asyncio.TimeoutError:
            return await ctx.send(" Tempo esgotado — operação cancelada.")

        if msg.content.strip().lower() != "confirmar":
            return await ctx.send(" Operação cancelada pelo usuário.")

        # Informa inicio
        status_message = await ctx.send(" Iniciando processo — deletando canais e cargos...")

        # === DELETAR CANAIS ===
        deleted_channels = 0
        errors = []

        # Convert to list to avoid mutation while iterating
        channels_list = list(guild.channels)
        for ch in channels_list:
            try:
                # evita deletar categorias enquanto canais dependentes são removidos? deletar na ordem natural é ok.
                await ch.delete(reason=f"Solicitado por {ctx.author} via c!apagartudo")
                deleted_channels += 1
                # pequena pausa para reduzir chance de rate-limits
                await asyncio.sleep(0.45)
            except Exception as e:
                errors.append(f"Canal '{getattr(ch, 'name', repr(ch))}': {e}")

        # === DELETAR CARGOS ===
        deleted_roles = 0
        # pega o membro do bot para checar posição
        bot_member = guild.get_member(self.bot.user.id)
        bot_top_position = bot_member.top_role.position if bot_member else 0

        # Construir lista de cargos a tentar deletar (ignora @everyone e cargos gerenciados)
        roles_to_try = [r for r in guild.roles if r != guild.default_role and not r.managed]
        # Ordena do menor para o maior para reduzir problemas de hierarquia ao deletar
        roles_to_try.sort(key=lambda r: r.position)

        for role in roles_to_try:
            # Nunca tentar apagar cargos com posição >= posição do bot (vai falhar)
            if role.position >= bot_top_position:
                errors.append(f"Pulando cargo '{role.name}' (posição >= posição do bot).")
                continue
            try:
                await role.delete(reason=f"Solicitado por {ctx.author} via c!apagartudo")
                deleted_roles += 1
                await asyncio.sleep(0.45)
            except Exception as e:
                errors.append(f"Cargo '{role.name}': {e}")

        # Resultado final
        summary = (
            f" Processo finalizado.\n\n"
            f"• Canais deletados: **{deleted_channels}**\n"
            f"• Cargos deletados: **{deleted_roles}**\n"
        )

        if errors:
            # se houver muitos erros, mostra apenas os 10 primeiros para não lotar o chat
            summary += "\n Alguns itens não puderam ser deletados ou foram pulados:\n"
            for err in errors[:10]:
                summary += f"- {err}\n"
            if len(errors) > 10:
                summary += f"... e mais {len(errors)-10} itens."

        await status_message.edit(content=summary)

async def setup(bot: commands.Bot):
    await bot.add_cog(ApagarTudo(bot))
