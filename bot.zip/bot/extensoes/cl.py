import discord
from discord.ext import commands
import json
import os

class CL(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def salvar_config(self, dados, arquivo="clconfig.json"):
        with open(arquivo, "w", encoding="utf-8") as f:
            json.dump(dados, f, indent=4, ensure_ascii=False)

    def carregar_config(self, arquivo="clconfig.json"):
        if not os.path.exists(arquivo):
            return {}
        with open(arquivo, "r", encoding="utf-8") as f:
            return json.load(f)

    def cor_aparencia(self, guild_id):
        try:
            with open("aparencia.json", "r", encoding="utf-8") as f:
                cores = json.load(f)
            return discord.Color.from_str(cores.get(str(guild_id), {}).get("cor", "#2f3136"))
        except:
            return discord.Color.from_str("#2f3136")

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
        
        if not message.guild:
            return
        
        config = self.carregar_config()
        palavra = config.get(str(message.guild.id))
        if not palavra:
            return
        
        if message.content.lower() == palavra.lower():
            try:
                def filtro(m):
                    return m.author == message.author
                await message.channel.purge(limit=100, check=filtro)
            except discord.Forbidden:
                # Se não tiver permissão, pode ignorar ou logar, sem enviar mensagem
                pass
            except Exception:
                pass

    async def exibir_embed_cl(self, interaction: discord.Interaction):
        config_file = "clconfig.json"
        if not os.path.exists(config_file):
            with open(config_file, "w", encoding="utf-8") as f:
                json.dump({}, f)

        with open(config_file, "r", encoding="utf-8") as f:
            config = json.load(f)

        bot = self.bot
        cor = self.cor_aparencia(interaction.guild.id)

        class PalavraModal(discord.ui.Modal, title="Definir Palavra CL"):
            palavra = discord.ui.TextInput(
                label="Nova palavra que ativa o CL",
                placeholder="Ex: cl",
                max_length=20
            )

            async def on_submit(self, modal_interaction: discord.Interaction):
                config[str(interaction.guild.id)] = self.palavra.value.lower()
                self_cog = bot.get_cog("CL")
                if self_cog:
                    self_cog.salvar_config(config, config_file)

                embed = discord.Embed(
                    description=f"Palavra CL definida como: `{self.palavra.value.lower()}`",
                    color=cor
                )
                await modal_interaction.response.send_message(embed=embed, ephemeral=True)

        class CLView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=60)

            @discord.ui.button(label="Definir Palavra", style=discord.ButtonStyle.secondary)
            async def definir(self, button_interaction: discord.Interaction, button: discord.ui.Button):
                if button_interaction.user != interaction.user:
                    return await button_interaction.response.send_message(
                        "Apenas quem abriu o painel pode usar este botão.",
                        ephemeral=True
                    )
                await button_interaction.response.send_modal(PalavraModal())

            @discord.ui.button(label="Voltar", style=discord.ButtonStyle.danger)
            async def voltar(self, button_interaction: discord.Interaction, button: discord.ui.Button):
                from extensoes.painel import PainelSelect  # Import local
                await button_interaction.message.edit(embed=None, view=PainelSelect(interaction))

        palavra_atual = config.get(str(interaction.guild.id), "Não definida")

        embed = discord.Embed(
            title="Configuração da Palavra CL",
            description=f"Palavra atual: `{palavra_atual}`",
            color=cor
        )
        embed.set_footer(text=f"Solicitado por: {interaction.user.display_name}", icon_url=interaction.user.display_avatar.url)

        await interaction.message.edit(embed=embed, view=CLView())

async def setup(bot):
    await bot.add_cog(CL(bot))