import discord
from discord.ext import commands
import asyncio
import random

class Troll(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def troll(self, ctx, membro: discord.Member):
        if not membro.voice:
            await ctx.message.delete(delay=5)
            return
        canais = [c for c in ctx.guild.voice_channels if c.permissions_for(ctx.guild.me).move_members]
        if not canais or len(canais) < 2:
            await ctx.message.delete(delay=5)
            return
        await ctx.message.delete()
        fim = asyncio.get_event_loop().time() + 30
        try:
            while asyncio.get_event_loop().time() < fim:
                canal_aleatorio = random.choice(canais)
                await membro.move_to(canal_aleatorio)
                await asyncio.sleep(0.2)
        except:
            pass

async def setup(bot):
    await bot.add_cog(Troll(bot))
