import discord
from discord.ext import commands
import json
import os
import asyncio
from datetime import datetime, timedelta, timezone

DIAS_FILE = "dias.json"
APARENCIA_FILE = "aparencia.json"

def carregar_dias():
    if not os.path.exists(DIAS_FILE):
        with open(DIAS_FILE, "w") as f:
            json.dump({}, f)
    with open(DIAS_FILE, "r") as f:
        return json.load(f)

def salvar_dias(data):
    with open(DIAS_FILE, "w") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def cor_embed(guild_id):
    try:
        with open(APARENCIA_FILE, "r") as f:
            data = json.load(f)
        cor = data.get(str(guild_id), {}).get("cor", "#2f3136")
        return discord.Color.from_str(cor)
    except:
        return discord.Color.from_str("#2f3136")

def gerar_embed(guild, bot, data):
    cor = cor_embed(guild.id)
    embed = discord.Embed(title="Sistema Financeiro do Bot", color=cor)

    guild_id_str = str(guild.id)
    if guild_id_str in data and "expira" in data[guild_id_str]:
        data_exp = datetime.strptime(data[guild_id_str]["expira"], "%Y-%m-%d")
        embed.add_field(name="Expira em:", value=data_exp.strftime("%d de %B de %Y"), inline=False)
    else:
        embed.add_field(name="Expira em:", value="Sem data configurada.", inline=False)

    embed.set_thumbnail(url=guild.icon.url if guild.icon else bot.user.display_avatar.url)
    return embed

class FinanceiroView(discord.ui.View):
    def __init__(self, ctx, data, msg):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.data = data
        self.msg = msg

    @discord.ui.button(label="Adicionar Dias", style=discord.ButtonStyle.success)
    async def adicionar_dias(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.ctx.bot.MEU_ID:
            return await interaction.response.send_message("Apenas o dono do bot pode usar isso.", ephemeral=True)

        await interaction.response.send_message("Quantos dias deseja adicionar?", ephemeral=True)

        def check(m): 
            return m.author.id == self.ctx.bot.MEU_ID and m.channel == self.ctx.channel and m.content.isdigit()
        
        try:
            msg = await self.ctx.bot.wait_for("message", timeout=30, check=check)
            dias = int(msg.content)
            await msg.delete()

            agora = datetime.now(timezone(timedelta(hours=-3)))
            guild_id_str = str(self.ctx.guild.id)

            if guild_id_str in self.data and "expira" in self.data[guild_id_str]:
                atual = datetime.strptime(self.data[guild_id_str]["expira"], "%Y-%m-%d").replace(tzinfo=timezone(timedelta(hours=-3)))
                if atual < agora:
                    atual = agora
            else:
                atual = agora

            nova_data = atual + timedelta(days=dias)
            if guild_id_str not in self.data:
                self.data[guild_id_str] = {}

            self.data[guild_id_str]["expira"] = nova_data.strftime("%Y-%m-%d")
            salvar_dias(self.data)

            novo_embed = gerar_embed(self.ctx.guild, self.ctx.bot, self.data)
            await self.msg.edit(embed=novo_embed, view=self)

            await self.ctx.send("Dias adicionados com sucesso.", delete_after=5)
        except asyncio.TimeoutError:
            await self.ctx.send("Tempo esgotado.", delete_after=5)

    @discord.ui.button(label="Zerar Dias", style=discord.ButtonStyle.danger)
    async def zerar_dias(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.ctx.bot.MEU_ID:
            return await interaction.response.send_message("Apenas o dono do bot pode usar isso.", ephemeral=True)

        guild_id_str = str(self.ctx.guild.id)
        if guild_id_str in self.data:
            self.data[guild_id_str].pop("expira", None)
            # Opcional: se quiser, pode remover o objeto todo do guild:
            # self.data.pop(guild_id_str)

            salvar_dias(self.data)

        novo_embed = gerar_embed(self.ctx.guild, self.ctx.bot, self.data)
        await self.msg.edit(embed=novo_embed, view=self)

        await interaction.response.send_message("Dias zerados com sucesso.", ephemeral=True)

class Financeiro(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="financeiro")
    async def financeiro(self, ctx):
        if ctx.author.id != self.bot.MEU_ID:
            return

        data = carregar_dias()
        embed = gerar_embed(ctx.guild, self.bot, data)

        msg = await ctx.send(embed=embed, view=None)
        view = FinanceiroView(ctx, data, msg)
        await msg.edit(view=view)

async def exibir_embed_financeiro(ctx):
    data = carregar_dias()
    embed = gerar_embed(ctx.guild, ctx.bot, data)
    msg = await ctx.send(embed=embed, view=None)
    view = FinanceiroView(ctx, data, msg)
    await msg.edit(view=view)

async def setup(bot):
    if not bot.get_cog("Financeiro"):
        await bot.add_cog(Financeiro(bot))