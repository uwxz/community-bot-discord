import discord
from discord.ext import commands
import json
from pathlib import Path

# Cor de fallback (Discord Dark Gray) caso a configuração não seja encontrada
DEFAULT_COLOR = 0x36393F 

def get_color(guild_id: int):
    # Caminho até a raiz do projeto
    base_path = Path(__file__).resolve().parent.parent
    file_path = base_path / "aparencia.json"

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return DEFAULT_COLOR
    except json.JSONDecodeError:
        return DEFAULT_COLOR

    guild_data = data.get(str(guild_id))
    if not guild_data:
        return DEFAULT_COLOR

    try:
        cor = guild_data["cor"]
        return int(cor.replace("#", ""), 16)
    except (KeyError, ValueError):
        return DEFAULT_COLOR

class Nuke(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.guild_only()  # <<< ADICIONADO ESTE CHECK
    @commands.has_permissions(manage_channels=True)
    async def nuke(self, ctx):
        # AQUI COMEÇA A LÓGICA DO COMANDO (que só roda se todos os checks passarem)
        
        canal_antigo = ctx.channel
        posicao = canal_antigo.position
        categoria = canal_antigo.category

        # Clona o canal antes de deletar
        canal_novo = await canal_antigo.clone(reason="Canal nukado!")
        await canal_antigo.delete()

        # Move para a mesma posição e categoria
        await canal_novo.edit(position=posicao, category=categoria)

        # Embed de confirmação
        embed = discord.Embed(
            description=f"Canal nukado por → ``{ctx.author}``",
            color=get_color(ctx.guild.id)
        )
        embed.set_footer(text=f"Executado por {ctx.author}", icon_url=ctx.author.display_avatar.url)

        await canal_novo.send(embed=embed)

    @nuke.error
    async def nuke_error(self, ctx, error):
        cor_erro = get_color(ctx.guild.id)
        
        # O erro é wrapado (envolvido) por CommandInvokeError.
        if hasattr(error, 'original'):
            error = error.original

        # 1. Tratamento de Permissão Faltante
        if isinstance(error, commands.MissingPermissions):
            description = "Você precisa da permissão `Gerenciar canais` para usar este comando."
        
        # 2. Tratamento para comandos executados em DM (guild_only)
        elif isinstance(error, commands.NoPrivateMessage):
            description = "Este comando só pode ser usado em servidores (Guilds)."
        
        # 3. Tratamento de Erro de Chave (ex: configuração da cor não encontrada)
        elif isinstance(error, KeyError):
            description = "Erro ao buscar a configuração de cor do servidor."
        
        # 4. Tratamento para quaisquer outros erros não esperados
        else:
            # Imprime o erro no console para depuração
            print(f"Erro inesperado no comando nuke: {error}") 
            # Mensagem genérica para o usuário
            description = "Ocorreu um erro interno ao tentar nukar o canal."
        
        embed = discord.Embed(
            description=description,
            color=cor_erro
        )
        await ctx.send(embed=embed, delete_after=5)

async def setup(bot):
    await bot.add_cog(Nuke(bot))