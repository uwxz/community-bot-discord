import discord
from discord.ext import commands
import json

APARENCIA_FILE = "aparencia.json"

class Status(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Listener correto
    @commands.Cog.listener()
    async def on_ready(self):
        try:
            with open(APARENCIA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)

            if data:
                guild_id = next(iter(data.keys()))
                prefixo = data[guild_id].get("prefixo", "!")
            else:
                prefixo = "!"

            # muda o status
            await self.bot.change_presence(
                status=discord.Status.online,
                activity=discord.Game(name=f"Use {prefixo}ajuda para comandos")
            )
            print(f" Status definido: Jogando Use {prefixo}ajuda para comandos")

        except Exception as e:
            print(f" Erro ao definir status: {e}")

async def setup(bot):  # obrigatório no discord.py 2.0+
    await bot.add_cog(Status(bot))
