import discord
from discord.ext import commands
import os
import json
from datetime import datetime, timedelta, timezone

# ID fixo do dono do bot
MEU_ID = 1184233208418685035

def carregar_permissoes():
    if not os.path.exists("permissoes.json"):
        with open("permissoes.json", "w") as f:
            json.dump([MEU_ID], f)
    with open("permissoes.json", "r") as f:
        return set(json.load(f))

def carregar_blperms():
    if not os.path.exists("blperms.json"):
        with open("blperms.json", "w") as f:
            json.dump({}, f)
    with open("blperms.json", "r") as f:
        return json.load(f)

def expirado(guild_id):
    if not os.path.exists("dias.json"):
        return True
    with open("dias.json", "r") as f:
        data = json.load(f)
    guild_str = str(guild_id)
    if guild_str not in data:
        return True
    expira = data[guild_str].get("expira")
    if not expira:
        return True
    try:
        data_expira = datetime.strptime(expira, "%Y-%m-%d").replace(tzinfo=timezone(timedelta(hours=-3)))
        agora = datetime.now(timezone(timedelta(hours=-3)))
        return agora > data_expira
    except:
        return True

def get_prefix(bot, message):
    try:
        with open("aparencia.json", "r") as f:
            data = json.load(f)
        gid = str(message.guild.id)
        return data.get(gid, {}).get("prefixo", "!")
    except:
        return "!"

intents = discord.Intents.all()
bot = commands.Bot(command_prefix=get_prefix, intents=intents)

bot.MEU_ID = MEU_ID
bot.permissoes = carregar_permissoes()
bot.blperms = carregar_blperms()

@bot.check
async def check_permissao(ctx):
    nome_cmd = ctx.command.name if ctx.command else None
    if nome_cmd in {"painel", "perm"}:
        return True
    if ctx.guild is None:
        return False
    if expirado(ctx.guild.id):
        return False
    if nome_cmd == "financeiro":
        return ctx.author.id == bot.MEU_ID
    if nome_cmd == "aparencia":
        return ctx.author.id == bot.MEU_ID or ctx.author.id == ctx.guild.owner_id
    if nome_cmd == "permissoes":
        return ctx.author.id == bot.MEU_ID or ctx.author.id == ctx.guild.owner_id
    if nome_cmd == "nuke":
        return ctx.author.guild_permissions.administrator
    if nome_cmd == "ban":
        return ctx.author.guild_permissions.ban_members
    if nome_cmd in {"ajuda", "pd"}:
        return True
    if nome_cmd == "blacklist":
        return str(ctx.author.id) in bot.blperms
    return ctx.author.id == bot.MEU_ID or ctx.author.id in bot.permissoes
    
@bot.command()
async def meu_id(ctx):
    await ctx.send(f"Seu ID é: {ctx.author.id}")

@bot.event
async def on_ready():
    print(f"🤖 Bot conectado como {bot.user}")

    extensoes = [
        "extensoes.pd",
        "extensoes.nuke",
        "extensoes.ban",
        "extensoes.permissoes",
        "extensoes.aparencia",
        "extensoes.blacklist",
        "extensoes.financeiro",
        "extensoes.coleira",
        "extensoes.troll",
        "extensoes.antibot",
        "extensoes.connect",
        "extensoes.contador",
        "extensoes.clear",
        "extensoes.painel",
        "extensoes.expulsar",
        "extensoes.emoji",
        "extensoes.logs",
        "extensoes.verificacao",
        "extensoes.codigo",
        "extensoes.divulgacao",
        "extensoes.insta",
        "extensoes.protecaocargos",
        "extensoes.apagartudo",
        "extensoes.status",
        "extensoes.backup",
        "extensoes.cl"
        
    ]

    for ext in extensoes:
        try:
            if ext in bot.extensions:
                await bot.unload_extension(ext)
            await bot.load_extension(ext)
            print(f"✅ {ext} carregada.")
        except Exception as e:
            print(f"❌ Erro ao carregar {ext}: {e}")

    if os.path.exists("seguranca"):
        for arquivo in os.listdir("seguranca"):
            if arquivo.endswith(".py"):
                nome_modulo = f"seguranca.{arquivo[:-3]}"
                try:
                    if nome_modulo in bot.extensions:
                        await bot.unload_extension(nome_modulo)
                    await bot.load_extension(nome_modulo)
                    print(f"✅ {nome_modulo} carregado.")
                except Exception as e:
                    print(f"❌ Erro ao carregar {nome_modulo}: {e}")

bot.run("MTQxOTMxNjM0MzI2MTYyNjU0OQ.GeC49s.xtP4Bif_2vr--8TuP4OVWW4aR7JviBbzdZCdL8")
